package th.co.truecorp.crmdev.util.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;

/**
 *
 * @author Paravit T.
 * 
 */
public class PropertiesLoader {
	
    private final String SUFFIX = ".properties";
    private boolean isLoadAsResourceBundle;

    public PropertiesLoader() {
    }

    public boolean isLoadAsResourceBundle() {
        return isLoadAsResourceBundle;
    }

    public void setLoadAsResourceBundle(boolean isLoadAsResourceBundle) {
        this.isLoadAsResourceBundle = isLoadAsResourceBundle;
    }

    public Properties getAllSystemProperty() {
        return System.getProperties();
    }

    public String getSystemProperty(String key) {
        return System.getProperty(key);
    }

    /**
     *
     * @param key
     * @param value
     * @return Previous Value
     */
    public String setSystemProperty(String key, String value) {
        return System.setProperty(key, value);
    }

    public Properties loadPropertiesFile(String fileName) throws IOException {
        Properties resultProp = null;
        InputStream inputStream = null;

        try {
            if (fileName != null) {
                if (!fileName.endsWith(SUFFIX)) {
                    return resultProp;
                }
            }
            
            File propertiesFile = new File(fileName);
            inputStream = new FileInputStream(propertiesFile);
            resultProp = new Properties();
            resultProp.load(inputStream);
        }
        finally {
            if (inputStream != null) {
                inputStream.close();
                inputStream = null;
            }
        }

        return resultProp;
    }

    public Properties loadProperties(String name, Locale locale)
        throws IOException {

        Properties resultProp = null;
        InputStream inputStream = null;

        try {
            if (name == null) {
                return resultProp;
            }

            if (name.startsWith("/")) {
                name = name.substring(1);
            }

            if (name.endsWith(SUFFIX)) {
                name = name.substring(0, name.length() - SUFFIX.length());
            }

            if (isLoadAsResourceBundle) {
                name = name.replace('/', '.');
                ResourceBundle rb = ResourceBundle.getBundle(name, locale);
                Enumeration<String> keys = rb.getKeys();

                resultProp = new Properties();
                while (keys.hasMoreElements()) {
                    String key = (String) keys.nextElement();
                    resultProp.put(key, rb.getString(key));
                }
            }
            else {
                name = name.replace('.', '/');
                if (!name.endsWith(SUFFIX)) {
                    name = name.concat(SUFFIX);
                }

                ClassLoader classLoader = PropertiesLoader.class.getClassLoader();
                inputStream = classLoader.getResourceAsStream(name);
                if (inputStream != null) {
                    resultProp = new Properties();
                    resultProp.load(inputStream);
                }
            }
        }
        finally {
            if (inputStream != null) {
                inputStream.close();
                inputStream = null;
            }
        }

        return resultProp;
    }

    public Properties loadProperties(String name) throws IOException {
        return loadProperties(name, Locale.getDefault());
    }

    public void storeProperties(Properties properties, String fileName)
        throws IOException {

        FileOutputStream outputStream = null;
        try {
            File propertiesFile = new File(fileName);
            outputStream = new FileOutputStream(propertiesFile);
            properties.store(outputStream, null);
        }
        finally {
            if (outputStream != null) {
                outputStream.close();
                outputStream = null;
            }
        }
    }
}