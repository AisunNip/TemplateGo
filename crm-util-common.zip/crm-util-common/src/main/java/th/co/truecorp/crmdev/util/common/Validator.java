package th.co.truecorp.crmdev.util.common;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 
 * @author Paravit T.
 *
 */
public class Validator {
	
	/*
	#######################
	# Regular Expression
	####################### 
 	X* --> Matches 0 or more
 	X+ --> Matches 1 or more
 	X? --> Matches 0 or 1
 	X{number} 	--> Matches number times. 
 	X{n,}	--> X, at least n times
 	X{n,m}	--> X, at least n but not more than m times
 	() 		--> Grouping
 	^ --> The beginning of a line
	$ --> The end of a line
	| --> Or
	\\d	--> Any digit, short for [0-9]
	\\D --> A non-digit, short for [^0-9]
	\\s	-->	A whitespace character, short for [ \t\n\x0b\r\f]
	\\S --> A non-whitespace character, for short for [^\s]
	\\w	--> A word character, short for [a-zA-Z_0-9]
	\\W	--> A non-word character [^\w]
	*/
	
	private final String CURRENCY			= "-?\\d{1,}\\.\\d{2}";
	private final String CITIZEN_ID 		= "\\d{13}";
	
	// THAI_PATTERN support Unicode only. \u0E01-\u0E5B
	private final String THAI_PATTERN 		= "[\u0E01-\u0E5B0-9_\\.\\s]+";
	private final String ENGLISH_PATTERN 	= "[A-Za-z0-9_\\.\\s]+";
	private final String SYMBOLS_PATTERN 	= "([\\u2000-\\u206F]|[\\u20A0-\\u20CF]|[\\u2100-\\u214F]|[\\u2190-\\u22FF]|[\\u2500-\\u27BF])+";
	
	private final String DIGIT_PATTERN 		= "-?\\d+";
	private final String DECIMAL_NUMBER_PATTERN = "-?\\d+\\.\\d{1,}";
	private final String MONTH_PATTERN 		= "(1|2|3|4|5|6|7|8|9|10|11|12)";
	private final String YEAR_PATTERN 		= "\\d{4}";
	
	// DD/MM/YYYY HH:MM:SS
	private final String DATE_TIME_PATTERN 	= "(0[1-9]|[1-2][0-9]|3[0-1])/(0[1-9]|10|11|12)/\\d{4} ([0-1][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]";
	//yyyy-MM-ddTHH:mm:ss.SSSXXX
	private final String DATE_TIME_PATTERN_JSON 	= "(\\d{4})-(\\d{2})-(\\d{2})T((\\d{2}):(\\d{2}):(\\d{2})\\.(\\d{3}))((\\+|-)(\\d{2}):(\\d{2}))";
	
	private final String MOBILE_NUM_PATTERN	= "(\\+66|66|0)\\d{9}";
	private final String PHONE_NUM_PATTERN 	= "(\\+66|66|0)\\d{8}";
	private final String EMAIL_PATTERN 		= "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@"
											+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
	
	public Validator() {
	}
	
	public boolean validator(String data, String regularExpression) {
		boolean isValid = false;
		
		if (data != null && !"".equals(data)) {
			isValid = data.matches(regularExpression);
		}
		
		return isValid;
	}
	
	public boolean isCurrency(String currency) {
		return this.validator(currency, CURRENCY);
	}
	
	public boolean isCitizenID(String citizenID) {
		return this.validator(citizenID, CITIZEN_ID);
	}
	
	public boolean isThai(String text) {
		return this.validator(text, THAI_PATTERN);
	}
	
	public boolean isEnglish(String text) {
		return this.validator(text, ENGLISH_PATTERN);
	}
	
	public boolean isSymbols(String text) {
		return this.validator(text, SYMBOLS_PATTERN);
	}
	
	public boolean isDigits(String digits) {
		return this.validator(digits, DIGIT_PATTERN);
	}
	
	public boolean isDecimal(String decimal) {
		return this.validator(decimal, DECIMAL_NUMBER_PATTERN);
	}
	
	public boolean isMonth(String month) {
		return this.validator(month, MONTH_PATTERN);
	}
	
	public boolean isYear(String year) {
		return this.validator(year, YEAR_PATTERN);
	}
	
	public boolean isDateTime(String dateTime) {
		boolean isValid = false;
		
		isValid = this.validator(dateTime, DATE_TIME_PATTERN);
		if (isValid) {
			String date_time[] = dateTime.split(" ");
			String date = date_time[0];
			String time = date_time[1];
			String d_m_y[] = date.split("/");
			String h_m_s[] = time.split(":");
			
			isValid = CalendarManager.isDateTime(Integer.parseInt(d_m_y[0]), Integer.parseInt(d_m_y[1]), Integer.parseInt(d_m_y[2])
			                                    , Integer.parseInt(h_m_s[0]), Integer.parseInt(h_m_s[1]), Integer.parseInt(h_m_s[2])
			                                    , CalendarManager.LOCALE_EN);
		}
		
		return isValid;
	}
	
	//support java 1.6
	public boolean isDateTimeJSON(String dateTime) {
		boolean isValid = false;
		
		isValid = this.validator(dateTime, DATE_TIME_PATTERN_JSON);
		if (isValid) {
			Pattern r8601 = Pattern.compile(DATE_TIME_PATTERN_JSON);
			Matcher m = r8601.matcher(dateTime);
			isValid = m.lookingAt();
		}
		
		return isValid;
	}
	
	public boolean isMobileNumber(String mobileNumber) {
		return this.validator(mobileNumber, MOBILE_NUM_PATTERN);
	}
	
	public boolean isPhoneNumber(String phoneNumber) {
		return this.validator(phoneNumber, PHONE_NUM_PATTERN);
	}
	
	public boolean isEmailAddress(String emailAddress) {
		return this.validator(emailAddress, EMAIL_PATTERN);
	}
	
	public boolean isURL(String urlParam) {
		boolean isValid = false;
		
		try {
			if (urlParam != null && !"".equals(urlParam)) {
				URL url = new URL(urlParam);
				String protocol = url.getProtocol();
				if ("http".equals(protocol) || "https".equals(protocol)) {
					isValid = true;
				}
			}
		}
		catch(MalformedURLException malURLEx) {
		}
		
		return isValid;
	}
	
	public boolean hasStringValue(String data) {
		boolean isValid = false;
		
		if (data != null && !"".equals(data)) {
			isValid = true;
		}
		
		return isValid;
	}
	
	public boolean hasDoubleValue(Double data) {
		boolean isValid = false;
		
		if (data != null && data != 0.00d) {
			isValid = true;
		}
		
		return isValid;
	}
	
	public boolean hasArrayValue(Object[] obj) {
		if (obj != null) {
			return obj.length > 0 ? true : false;
		}
		else {
			return false;
		}
	}
	
	public boolean isBlankValue(Object object) {
		if (object == null)
			return true;
		
		if (object instanceof String) {
			String objString = (String) object;
			
			if (objString == null || objString.length() == 0 || "".equals(objString.trim())) {
				return true;
			}
			else {
				if ("?".equalsIgnoreCase(objString.trim()))
					return true;
			}
		}
		
		return false;
	}
}