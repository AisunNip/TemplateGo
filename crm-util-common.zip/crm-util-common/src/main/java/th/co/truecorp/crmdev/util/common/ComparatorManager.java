package th.co.truecorp.crmdev.util.common;

import java.util.Calendar;
import java.util.Date;

/**
 * 
 * @author Paravit T.
 * Ex.
 * public class CustomerComparator implements Comparator<CustomerBean> {
 * 		private ComparatorManager cm;
 * 		
 * 		public CustomerComparator() {
 * 			this.cm = new ComparatorManager();
 * 		}
 * 
 * 		public int compare(CustomerBean obj1, CustomerBean obj2) {
 * 			return this.cm.compareData(obj1.getFirstName(), obj2.getFirstName());
 * 		}
 * }
 * 
 * Collections.sort(dataArrayList, new CustomerComparator());
 * Arrays.sort(dataBeanArray, new CustomerComparator());
 * 
 */
public class ComparatorManager {

	private boolean isDescending;

	public ComparatorManager() {
		this.setDescending(true);
	}

	public boolean isDescending() {
		return isDescending;
	}

	public void setDescending(boolean isDescending) {
		this.isDescending = isDescending;
	}
	
	public int compareData(int data1, int data2) {
		int result = 0;
		
		if (this.isDescending()) {
			if (data1 < data2) {
				result = 1;
			}
			else if (data1 > data2) {
				result = -1;
			}
		}
		else {
			if (data1 < data2) {
				result = -1;
			}
			else if (data1 > data2) {
				result = 1;
			}
		}

		return result;
	}

	public int compareData(long data1, long data2) {
		int result = 0;

		if (this.isDescending()) {
			if (data1 < data2) {
				result = 1;
			}
			else if (data1 > data2) {
				result = -1;
			}
		}
		else {
			if (data1 < data2) {
				result = -1;
			}
			else if (data1 > data2) {
				result = 1;
			}
		}

		return result;
	}

	public int compareData(double data1, double data2) {
		int result = 0;

		if (this.isDescending()) {
			if (data1 < data2) {
				result = 1;
			}
			else if (data1 > data2) {
				result = -1;
			}
		}
		else {
			if (data1 < data2) {
				result = -1;
			}
			else if (data1 > data2) {
				result = 1;
			}
		}

		return result;
	}

	public int compareData(short data1, short data2) {
		int result = 0;

		if (this.isDescending()) {
			if (data1 < data2) {
				result = 1;
			}
			else if (data1 > data2) {
				result = -1;
			}
		}
		else {
			if (data1 < data2) {
				result = -1;
			}
			else if (data1 > data2) {
				result = 1;
			}
		}

		return result;
	}

	public int compareData(String data1, String data2) {
		int result = 0;
		
		if (this.isDescending()) {
			result = data1.compareTo(data2) * -1;
		}
		else {
			result = data1.compareTo(data2);
		}

		return result;
	}
	
	public int compareData(Calendar data1, Calendar data2) {
		long dataLong1 = 0L;
		long dataLong2 = 0L;
		
		if (data1 != null) {
			dataLong1 = data1.getTimeInMillis();
		}
		
		if (data2 != null) {
			dataLong2 = data2.getTimeInMillis();
		}
		
		return this.compareData(dataLong1, dataLong2);
	}
	
	public int compareData(Date data1, Date data2) {
		long dataLong1 = 0L;
		long dataLong2 = 0L;
		
		if (data1 != null) {
			dataLong1 = data1.getTime();
		}
		
		if (data2 != null) {
			dataLong2 = data2.getTime();
		}
		
		return this.compareData(dataLong1, dataLong2);
	}
	
}