package th.co.truecorp.crmdev.util.common;

import java.util.Enumeration;
import java.util.Properties;
import java.util.ResourceBundle;

import th.co.truecorp.crmdev.util.common.bean.BackendInfo;
import th.co.truecorp.crmdev.util.common.bean.Constants;
import th.co.truecorp.crmdev.util.common.bean.ErrorCodeResp;

public class ErrorCodeManager {
	
	private static ErrorCodeManager instance;
	private static MessageManager msgManager;
	private static Properties systemProp;
	private static Properties moduleProp;
	private static Properties errorProp;
	
	// System Code
	public static final String SYSTEM_CODE = "VSB";
	public static final String MODULE_CODE = "EC";
	
	// Error Code
	public static final String REQUIRED_CODE = "101000";
	public static final String NOT_FOUND_CODE = "201000";
	public static final String DATA_INVALID_CODE = "203000";
	public static final String APPLICATION_CODE = "400000";
	
	private ErrorCodeManager() {
	}

	public static synchronized ErrorCodeManager getInstance() {
		if (instance == null) {
			instance = new ErrorCodeManager();
			
			msgManager = MessageManager.getInstance();
			msgManager.setBaseName(Constants.MESSAGE_BUNDLE);
			
			systemProp = instance.loadProperties(Constants.SYSTEM_CODE_BUNDLE);
			moduleProp = instance.loadProperties(Constants.MODULE_CODE_BUNDLE);
			errorProp  = instance.loadProperties(Constants.ERROR_CODE_BUNDLE);
		}
		
		return instance;
	}
	
	private Properties loadProperties(String name) {
		Properties properties = new Properties();
		
		ResourceBundle rb = ResourceBundle.getBundle(name);
		Enumeration<String> keys = rb.getKeys();
		
		while (keys.hasMoreElements()) {
			String key = keys.nextElement();
            properties.put(key, rb.getString(key));
		}
		
		return properties;
	}
	
	private ErrorCodeResp generateMessage(String errorCode, String errorCodeDesc, String errorMessage) {
		StringBuilder errorMsgBuffer = new StringBuilder();
		errorMsgBuffer.append("[");
		errorMsgBuffer.append(errorCode);
		errorMsgBuffer.append("] ");
		errorMsgBuffer.append("[");
		errorMsgBuffer.append(errorCodeDesc);
		errorMsgBuffer.append("] ");
		errorMsgBuffer.append("[");
		errorMsgBuffer.append(errorMessage);
		errorMsgBuffer.append("]");
		
		ErrorCodeResp errorCodeResp = new ErrorCodeResp();
		errorCodeResp.setErrorCode(errorCode);
		errorCodeResp.setErrorMessage(errorMsgBuffer.toString());
		
		return errorCodeResp;
	}
	
	private ErrorCodeResp validateRequired(String systemCode, String moduleCode
		, String errorCode, BackendInfo backendInfo, boolean isCallBackendAPI) {
		
		ErrorCodeResp errorCodeResp = null;
		String errorMessage = null;
		
		if (systemCode == null || "".equals(systemCode)) {	
			errorMessage = msgManager.createMessage("ErrorCodeManager.RequiredCode", "systemCode");
		}
		
		if (moduleCode == null || "".equals(moduleCode)) {
			errorMessage = msgManager.createMessage("ErrorCodeManager.RequiredCode", "moduleCode");
		}
		
		if (errorCode == null || "".equals(errorCode)) {
			errorMessage = msgManager.createMessage("ErrorCodeManager.RequiredCode", "errorCode");
		}
		
		if (isCallBackendAPI && backendInfo == null) {
			errorMessage = msgManager.createMessage("ErrorCodeManager.RequiredCode", "backendInfo");
		}
		
		if (errorMessage != null) {
			String standardErrorCode = SYSTEM_CODE + MODULE_CODE + "B" + REQUIRED_CODE + "2";
			String errorCodeDesc = "REQUIRED_CODE";
			
			if (isCallBackendAPI) {
				errorCodeResp = this.generateMessage(backendInfo.getErrorCode(), "", backendInfo.getErrorMessage());
				
				ErrorCodeResp errorCodeRespLevel2 = this.generateMessage(standardErrorCode, errorCodeDesc, errorMessage);
				errorCodeResp.setErrorMessage(errorCodeResp.getErrorMessage() + " " + errorCodeRespLevel2.getErrorMessage());
			}
			else {
				errorCodeResp = this.generateMessage(standardErrorCode, errorCodeDesc, errorMessage);
			}
		}
		
		return errorCodeResp;
	}
	
	private ErrorCodeResp validateNotFound(String systemCode, String moduleCode
		, String errorCode, BackendInfo backendInfo, boolean isCallBackendAPI) {
		
		ErrorCodeResp errorCodeResp = null;
		String errorMessage = null;
		
		String systemName = systemProp.getProperty(systemCode);
		if (systemName == null) {
			errorMessage = msgManager.createMessage("ErrorCodeManager.NotFoundCode", "systemCode: " + systemCode);
		}
		
		String moduleName = moduleProp.getProperty(moduleCode);
		if (moduleName == null) {
			errorMessage = msgManager.createMessage("ErrorCodeManager.NotFoundCode", "moduleCode: " + moduleCode);
		}
		
		String errorPattern = errorProp.getProperty(errorCode);
		if (errorPattern == null) {
			errorMessage = msgManager.createMessage("ErrorCodeManager.NotFoundCode", "errorCode: " + errorCode);
		}
		
		if (errorMessage != null) {
			String standardErrorCode = SYSTEM_CODE + MODULE_CODE + "B" + NOT_FOUND_CODE + "2";
			String errorCodeDesc = "NOT_FOUND_CODE";
			
			if (isCallBackendAPI) {
				errorCodeResp = this.generateMessage(backendInfo.getErrorCode(), "", backendInfo.getErrorMessage());
				
				ErrorCodeResp errorCodeRespLevel2 = this.generateMessage(standardErrorCode, errorCodeDesc, errorMessage);
				errorCodeResp.setErrorMessage(errorCodeResp.getErrorMessage() + " " + errorCodeRespLevel2.getErrorMessage());
			}
			else {
				errorCodeResp = this.generateMessage(standardErrorCode, errorCodeDesc, errorMessage);
			}
		}
		
		return errorCodeResp;
	}
	
	/**
	 * This method used for error which involve with the backend API
	 * and override error classification.
	 * @param systemCode is required.
	 * @param moduleCode is required.
	 * @param errorCode is required.
	 * @param errorMessage is optional and used with placehold in properties file.
	 * @param backendInfo is optional.
	 * @param isCallBackendAPI is required.
	 * @return ErrorCodeResp
	 */
	private ErrorCodeResp generate(String systemCode, String moduleCode, String errorCode, String errorMessage[]
		, BackendInfo backendInfo, boolean isCallBackendAPI) {
		
		ErrorCodeResp errorCodeResp = null;
		
		try {
			errorCodeResp = this.validateRequired(systemCode, moduleCode, errorCode, backendInfo, isCallBackendAPI);
			if (errorCodeResp != null) {
				return errorCodeResp;
			}
			
			errorCodeResp = this.validateNotFound(systemCode, moduleCode, errorCode, backendInfo, isCallBackendAPI);
			if (errorCodeResp != null) {
				return errorCodeResp;
			}
			
			String errorPattern = errorProp.getProperty(errorCode);
			
			String errorPatternArray[] = errorPattern.split("\\|");
			if (errorPatternArray.length != 4) {
				String standardErrorCode = SYSTEM_CODE + MODULE_CODE + "A" + DATA_INVALID_CODE + "4";
				String errorCodeDesc = "DATA_INVALID_CODE";
				String tmpErrorMsg = msgManager.createMessage("ErrorCodeManager.ErrorPatternInvalid");
				
				if (isCallBackendAPI) {
					errorCodeResp = this.generateMessage(backendInfo.getErrorCode(), "", backendInfo.getErrorMessage());
					
					ErrorCodeResp errorCodeRespLevel2 = this.generateMessage(standardErrorCode, errorCodeDesc, tmpErrorMsg);
					errorCodeResp.setErrorMessage(errorCodeResp.getErrorMessage() + " " + errorCodeRespLevel2.getErrorMessage());
				}
				else {
					errorCodeResp = this.generateMessage(standardErrorCode, errorCodeDesc, tmpErrorMsg);
				}
			}
			
			if (errorCodeResp != null) {
				return errorCodeResp;
			}
			
			String errorMsgPattern = errorPatternArray[0];
			String errorCodeDesc = errorPatternArray[1];
			String errorClassify = errorPatternArray[2];
			String severityType = errorPatternArray[3];
			
			StringBuilder standardErrorCodeBuffer = new StringBuilder();
			standardErrorCodeBuffer.append(systemCode);
			standardErrorCodeBuffer.append(moduleCode);
			standardErrorCodeBuffer.append(errorClassify);
			standardErrorCodeBuffer.append(errorCode);
			standardErrorCodeBuffer.append(severityType);
			
			if (isCallBackendAPI) {
				errorCodeResp = this.generateMessage(backendInfo.getErrorCode(), "", backendInfo.getErrorMessage());
				
				String tmpErrorMessage[] = {backendInfo.getServiceName(), backendInfo.getMethodName()};
				errorMsgPattern = msgManager.createMessageByPattern(errorMsgPattern, tmpErrorMessage);
				ErrorCodeResp errorCodeRespLevel2 = this.generateMessage(standardErrorCodeBuffer.toString(), errorCodeDesc, errorMsgPattern);
				
				errorCodeResp.setErrorMessage(errorCodeResp.getErrorMessage() + " " + errorCodeRespLevel2.getErrorMessage());
			}
			else {
				// [VCAACS8020005] [VCARE_DATABASE_CODE] [ORA - zzzzzzzzz]
				if (errorMessage != null) {
					errorMsgPattern = msgManager.createMessageByPattern(errorMsgPattern, errorMessage);
				}
				
				errorCodeResp = this.generateMessage(standardErrorCodeBuffer.toString(), errorCodeDesc, errorMsgPattern);	
			}
		}
		catch (Throwable t) {
			String standardErrorCode = SYSTEM_CODE + MODULE_CODE + "A" + APPLICATION_CODE + "5";
			String errorCodeDesc = "APPLICATION_CODE";
			String tmpErrorMessage = t.getClass().getName() + " " + t.getMessage();
			
			if (isCallBackendAPI) {
				errorCodeResp = this.generateMessage(backendInfo.getErrorCode(), "", backendInfo.getErrorMessage());
				
				ErrorCodeResp errorCodeRespLevel2 = this.generateMessage(standardErrorCode, errorCodeDesc, tmpErrorMessage);
				errorCodeResp.setErrorMessage(errorCodeResp.getErrorMessage() + " " + errorCodeRespLevel2.getErrorMessage());
			}
			else {
				errorCodeResp = this.generateMessage(standardErrorCode, errorCodeDesc, tmpErrorMessage);
			}
		}
		finally {
			
		}
		
		return errorCodeResp;
	}
	
	/**
	 * This method used for error which involve with the backend API.
	 * @param systemCode is required.
	 * @param moduleCode is required.
	 * @param errorCode is required.
	 * @param backendInfo is required.
	 * @return ErrorCodeResp
	 */
	public ErrorCodeResp generateByAPI(String systemCode, String moduleCode, String errorCode, BackendInfo backendInfo) {
		boolean isCallBackendAPI = true;
		return this.generate(systemCode, moduleCode, errorCode, null, backendInfo, isCallBackendAPI);
	}
	
	/**
	 * This method used for another error which not involve with the backend API.
	 * @param systemCode is required.
	 * @param moduleCode is required.
	 * @param errorCode is required.
	 * @param errorMessage is optional.
	 * @return ErrorCodeResp
	 */
	public ErrorCodeResp generate(String systemCode, String moduleCode, String errorCode, String errorMessage[]) {
		BackendInfo backendInfo = null;
		boolean isCallBackendAPI = false;
		
		return this.generate(systemCode, moduleCode, errorCode, errorMessage, backendInfo, isCallBackendAPI);		
	}
	
	/**
	 * This method used for another error which not involve with the backend API.
	 * @param systemCode is required.
	 * @param moduleCode is required.
	 * @param errorCode is required.
	 * @param errorMessage is optional.
	 * @return ErrorCodeResp
	 */
	public ErrorCodeResp generate(String systemCode, String moduleCode, String errorCode, String errorMessage) {
		BackendInfo backendInfo = null;
		boolean isCallBackendAPI = false;
		String errorMsg[] = null;
		
		if(errorMessage != null) {
			errorMsg = new String[1];
			errorMsg[0] = errorMessage;
		}
		
		return this.generate(systemCode, moduleCode, errorCode, errorMsg, backendInfo, isCallBackendAPI);		
	}
	
	public boolean isDataNotFound(String errorCode) {
		boolean isDataNotFound = false;
		
		if (errorCode != null) {
			if (errorCode.contains(ErrorCodeManager.NOT_FOUND_CODE)) {
				isDataNotFound = true;
			}
		}
		
		return isDataNotFound;
	}
}