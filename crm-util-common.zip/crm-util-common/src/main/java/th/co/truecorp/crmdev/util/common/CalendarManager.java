package th.co.truecorp.crmdev.util.common;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 *
 * @author Paravit T.
 * 
 */
public class CalendarManager {
	
	public static final Locale LOCALE_TH = new Locale("th", "TH");
	// Japanese
	public static final Locale LOCALE_JP = new Locale("ja", "JP");
	public static final Locale LOCALE_EN = Locale.ENGLISH;
	
	// "UTC" "Asia/Bangkok" "GMT+07:00"
	public static final String TIME_ZONE = "GMT+07:00";
	
	public static final String DATE_TIME_PATTERN = "dd/MM/yyyy HH:mm:ss";
	public static final String DATE_PATTERN = "dd/MM/yyyy";
	
	public static final String WEB_SERV_DATE_TIME_PATTERN 	= "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
	public static final String IWD_DATE_TIME_PATTERN 		= "yyyy-MM-dd'T'HH:mm:ss.SSSZ";
	public static final String SIEBEL_DATE_TIME_PATTERN 	= "MM/dd/yyyy HH:mm:ss";
	
	private static final String VALID_DATE_TIME_PATTERN = "[0-3][0-9]/[0-1][0-9]/\\d{4} [0-2][0-9]:[0-5][0-9]:[0-5][0-9]";
	private static final String VALID_DATE_PATTERN = "[0-3][0-9]/[0-1][0-9]/\\d{4}";

	private static final double DAY_IN_MILLISEC = 86400000d; // (24 * 60 * 60 * 1000)
//	private static final double HOUR_IN_MILLISEC = 3600000d; // (60 * 60 * 1000)
	
	public static Calendar getThaiCalendar() {
		return Calendar.getInstance(TimeZone.getTimeZone(CalendarManager.TIME_ZONE), CalendarManager.LOCALE_TH);
	}

	public static Calendar getEngCalendar() {
		return Calendar.getInstance(TimeZone.getTimeZone(CalendarManager.TIME_ZONE), Locale.ENGLISH);
	}
	
	public static String[] getAllTimeZoneID() {
		String[] timeZoneID = TimeZone.getAvailableIDs();
		Arrays.sort(timeZoneID);
		return timeZoneID;
	}
	
	public static Calendar getCalendar(Locale locale, TimeZone timeZone) {
		return Calendar.getInstance(timeZone, locale);
	}

	public static Calendar getCalendar(Locale locale) {
		return Calendar.getInstance(locale);
	}
	
	public static String getAMPM(Calendar cal) {
		String amPM = null;
		
		if (cal != null) {
			if (cal.get(Calendar.AM_PM) == Calendar.AM) {
				amPM = "AM";
			}
			else {
				amPM = "PM";
			}
		}
		
		return amPM;
	}
	
	public static Calendar setStartDay(Calendar cal) {
		if (cal != null) {
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
		}
		
		return cal;
	}
	
	public static Calendar setEndDay(Calendar cal) {
		if (cal != null) {
			cal.set(Calendar.HOUR_OF_DAY, 23);
			cal.set(Calendar.MINUTE, 59);
			cal.set(Calendar.SECOND, 59);
			cal.set(Calendar.MILLISECOND, 0);
		}
		
		return cal;
	}
	
	public static Calendar setLastDayOfMonth(Calendar cal) {
		if (cal != null) {
			int lastDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
			cal.set(Calendar.DAY_OF_MONTH, lastDay);
		}
		
		return cal;
	}
	
	public static Calendar addDay(Calendar cal, int amountOfDay) {
		if (cal != null && amountOfDay > 0) {
			cal.add(Calendar.DAY_OF_MONTH, amountOfDay);
		}
		
		return cal;
	}
	
	public static Calendar subtractDay(Calendar cal, int amountOfDay) {
		if (cal != null && amountOfDay > 0) {
			cal.add(Calendar.DAY_OF_MONTH, (amountOfDay * -1));
		}
		
		return cal;
	}
	
	public static boolean isFutureDate(Calendar cal) {
		boolean isFutureDate = false;
		
		if (cal != null) {
			Calendar currCalendar = Calendar.getInstance(cal.getTimeZone());
			isFutureDate = currCalendar.before(cal);
		}
		
		return isFutureDate;
	}
	
	public static boolean isPastDate(Calendar cal) {
		boolean isPastDate = false;
		
		if (cal != null) {
			Calendar currCalendar = Calendar.getInstance(cal.getTimeZone());
			isPastDate = currCalendar.after(cal);
		}
		
		return isPastDate;
	}
	
	public static boolean isSameDate(Calendar cal1, Calendar cal2) {
		boolean isSameDate = false;
		
		if (cal1 != null && cal2 != null) {
			if ((cal1.get(Calendar.DATE) == cal2.get(Calendar.DATE))
				&& (cal1.get(Calendar.MONTH) == cal2.get(Calendar.MONTH))
				&& (cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR))) {
				isSameDate = true;
			}
		}
		
		return isSameDate;
	}
	
	public static boolean isDate(int date, int month, int year, Locale locale) {
		boolean isDate = false;
		
		try {
			if (locale == null) {
				locale = CalendarManager.LOCALE_TH;
			}
			
			Calendar cal = CalendarManager.getCalendar(locale);
			cal.setLenient(false);
			cal.set(Calendar.DATE, date);
			cal.set(Calendar.MONTH, month - 1);
			cal.set(Calendar.YEAR, year);
			cal.getTime();
			isDate = true;
		}
		catch (IllegalArgumentException argEx) {
			isDate = false;
		}
		
		return isDate;
	}
	
	public static boolean isDateTime(int date, int month, int year
		, int hour, int minute, int second, Locale locale) {
		
		boolean isDateTime = false;
		
		try {
			if (locale == null) {
				locale = CalendarManager.LOCALE_TH;
			}
			
			Calendar cal = CalendarManager.getCalendar(locale);
			cal.setLenient(false);
			cal.set(Calendar.DATE, date);
			cal.set(Calendar.MONTH, month - 1);
			cal.set(Calendar.YEAR, year);
			cal.set(Calendar.HOUR_OF_DAY, hour);
			cal.set(Calendar.MINUTE, minute);
			cal.set(Calendar.SECOND, second);
			cal.getTime();
			isDateTime = true;
		}
		catch (IllegalArgumentException argEx) {
			isDateTime = false;
		}
		
		return isDateTime;
	}
	
	/**
	 * 
	 * @param dateTime validate format DD/MM/YYYY HH:MM:SS only.
	 * @return boolean
	 */
	public static boolean isValidDateTime(String dateTime) {
		boolean isValid = false;
		
		if (dateTime != null && !"".equals(dateTime)) {
			isValid = dateTime.matches(VALID_DATE_TIME_PATTERN);
			
			if (isValid) {
				String date_time[] = dateTime.split(" ");
				String date = date_time[0];
				String time = date_time[1];
				String d_m_y[] = date.split("/");
				String h_m_s[] = time.split(":");
				
				isValid = CalendarManager.isDateTime(Integer.parseInt(d_m_y[0]), Integer.parseInt(d_m_y[1]), Integer.parseInt(d_m_y[2])
				          , Integer.parseInt(h_m_s[0]), Integer.parseInt(h_m_s[1]), Integer.parseInt(h_m_s[2])
				          , CalendarManager.LOCALE_EN);
			}
		}
		
		return isValid;
	}
	
	/**
	 * 
	 * @param date validate format DD/MM/YYYY only.
	 * @return boolean
	 */
	public static boolean isValidDate(String date) {
		boolean isValid = false;
		
		if (date != null && !"".equals(date)) {
			isValid = date.matches(VALID_DATE_PATTERN);
			if (isValid) {
				String[] dd_mm_yyyy = date.split("/");
				
				isValid = CalendarManager.isDate(Integer.parseInt(dd_mm_yyyy[0]), Integer.parseInt(dd_mm_yyyy[1])
						  , Integer.parseInt(dd_mm_yyyy[2]), CalendarManager.LOCALE_EN);
			}
		}
		
		return isValid;
	}

	public static long getTimeInMillis(int date, int month, int year, int hour,
		int minute, int second, Locale locale) {
		
		long millisecond = 0L;
		
		try {
			if (locale == null) {
				locale = CalendarManager.LOCALE_TH;
			}
			
			Calendar cal = CalendarManager.getCalendar(locale);
			cal.setLenient(false);
			cal.set(Calendar.DATE, date);
			cal.set(Calendar.MONTH, month - 1);
			cal.set(Calendar.YEAR, year);
			cal.set(Calendar.HOUR_OF_DAY, hour);
			cal.set(Calendar.MINUTE, minute);
			cal.set(Calendar.SECOND, second);
			millisecond = cal.getTimeInMillis();
		}
		catch (IllegalArgumentException argEx) {
		}
		
		return millisecond;
	}

	public static String convertSecondToHHMMSS(int second) {
		int tempSecond = second % 60;
		int tempMinute = second / 60;
		int tempHour = tempMinute / 60;
		tempMinute = tempMinute - (tempHour * 60);

		String result = "";
		if (tempHour < 10) {
			result = "0" + String.valueOf(tempHour) + ":";
		}
		else {
			result = String.valueOf(tempHour) + ":";
		}

		if (tempMinute < 10) {
			result = result + "0" + String.valueOf(tempMinute) + ":";
		}
		else {
			result = result + String.valueOf(tempMinute) + ":";
		}

		if (tempSecond < 10) {
			result = result + "0" + String.valueOf(tempSecond);
		}
		else {
			result = result + String.valueOf(tempSecond);
		}

		return result;

		/*
		 * Test OK Calendar cal =
		 * CalendarManager.getCalendar(CalendarManager.LOCALE_EN); cal.clear();
		 * cal.set(Calendar.SECOND, second); SimpleDateFormat timeFormat = new
		 * SimpleDateFormat("HH:mm:ss", CalendarManager.LOCALE_EN); return
		 * timeFormat.format(cal.getTime());
		 */
	}

	/**
	 * @param HHMMSS (Format HH:MM:SS)
	 * @return Second
	 */
	public static int convertHHMMSSToSecond(String HHMMSS) {
		int result = 0;
		
		if (HHMMSS != null && HHMMSS.length() > 7) {
			String time[] = HHMMSS.split(":");
			if (time.length == 3) {
				int hour = Integer.parseInt(time[0]);
				int minute = Integer.parseInt(time[1]);
				int second = Integer.parseInt(time[2]);

				result = second + (minute * 60) + (hour * 60 * 60);
			}
		}
		
		return result;
	}

	/**
	 * @param sourceFormat is required.
	 * @param resultFormat is required.
	 * @param data is required.
	 * @param locale is required.
	 * @return a String
	 */
	public static String convertFormatDate(String sourceFormat, String resultFormat
		, String data, Locale locale) {
		
		String result = data;
		
		try {
			if (data != null && !"".equals(data)) {
				SimpleDateFormat inputDateFormat = new SimpleDateFormat(sourceFormat, locale);
				inputDateFormat.setTimeZone(TimeZone.getTimeZone(CalendarManager.TIME_ZONE));
				Date date = inputDateFormat.parse(data);

				SimpleDateFormat outputDateFormat = new SimpleDateFormat(resultFormat, locale);
				outputDateFormat.setTimeZone(TimeZone.getTimeZone(CalendarManager.TIME_ZONE));
				result = outputDateFormat.format(date);
			}
		}
		catch (ParseException e) {
		}
		
		return result;
	}
	
	public static Calendar timestampToCalendar(Timestamp timeStamp, Locale locale) {
		Calendar cal = null;
		
		if (timeStamp != null) {
			cal = Calendar.getInstance(TimeZone.getTimeZone(CalendarManager.TIME_ZONE), locale);
			cal.setTimeInMillis(timeStamp.getTime());
		}
		
		return cal;
	}
	
	public static Timestamp calendarToTimestamp(Calendar cal) {
		Timestamp timeStamp = null;
		
		if (cal != null) {
			timeStamp = new Timestamp(cal.getTimeInMillis());
		}
		
		return timeStamp;
	}
	
	public static LocalDate calendarToLocalDate(Calendar cal) {
		LocalDate localDate  = null;
		
		if (cal != null) {
			localDate = LocalDate.of(cal.get(Calendar.YEAR)
						, cal.get(Calendar.MONTH) + 1
						, cal.get(Calendar.DAY_OF_MONTH));
		}
		
		return localDate;
	}
	
	public static LocalDateTime calendarToLocalDateTime(Calendar cal) {
		LocalDateTime localDateTime  = null;
		
		if (cal != null) {
			localDateTime = LocalDateTime.of(cal.get(Calendar.YEAR)
							, cal.get(Calendar.MONTH) + 1
							, cal.get(Calendar.DAY_OF_MONTH)
							, cal.get(Calendar.HOUR_OF_DAY)
							, cal.get(Calendar.MINUTE)
							, cal.get(Calendar.SECOND));
		}
		
		return localDateTime;
	}
	
	public static Timestamp dateToTimestamp(Date date) {
		Timestamp timeStamp = null;
		
		if (date != null) {
			timeStamp = new Timestamp(date.getTime());
		}
		
		return timeStamp;
	}
	
	public static Date stringToDate(String dateTime, String pattern, Locale locale) {
		Date date = null;
		
		try {
			if (dateTime != null && !"".equals(dateTime)) {
				SimpleDateFormat dateFormat = new SimpleDateFormat(pattern, locale);
				dateFormat.setTimeZone(TimeZone.getTimeZone(CalendarManager.TIME_ZONE));
				date = dateFormat.parse(dateTime);
			}
		}
		catch (ParseException e) {
		}
		
		return date;
	}
	
	public static Calendar dateToCalendar(Date dateTime, Locale locale) {
		Calendar cal = null;
		
		if (dateTime != null) {
			cal = Calendar.getInstance(TimeZone.getTimeZone(CalendarManager.TIME_ZONE), locale);
			cal.setTime(dateTime);
		}
		
		return cal;
	}
	
	public static Calendar stringToCalendar(String dateTime, String pattern, Locale locale) {
		Calendar cal = null;
		
		Date date = CalendarManager.stringToDate(dateTime, pattern, locale);
		if (date != null) {
			cal = Calendar.getInstance(TimeZone.getTimeZone(CalendarManager.TIME_ZONE), locale);
			cal.setTime(date);
		}
		
		return cal;
	}
	
	public static String calendarToString(Calendar cal, String pattern, Locale locale) {
		String dateTime = null;
		
		try {
			if (cal != null) {
				SimpleDateFormat dateFormat = new SimpleDateFormat(pattern, locale);
				dateFormat.setTimeZone(TimeZone.getTimeZone(CalendarManager.TIME_ZONE));
				dateTime = dateFormat.format(cal.getTime());
			}
		}
		catch (Exception e) {
		}
		
		return dateTime;
	}
	
	public static String dateToString(Date date, String pattern, Locale locale) {
		String dateTime = null;
		
		try {
			if (date != null) {
				SimpleDateFormat dateFormat = new SimpleDateFormat(pattern, locale);
				dateFormat.setTimeZone(TimeZone.getTimeZone(CalendarManager.TIME_ZONE));
				dateTime = dateFormat.format(date);
			}
		}
		catch (Exception e) {
		}
		
		return dateTime;
	}
	
	public static String changeFormat(String dateTime, String srcPattern
		, String destPattern, Locale locale) {
		
		String resultDate = null;
		
		try {
			if (dateTime != null && !"".equals(dateTime)) {
				SimpleDateFormat dateFormat = new SimpleDateFormat(srcPattern, locale);
				dateFormat.setTimeZone(TimeZone.getTimeZone(CalendarManager.TIME_ZONE));
				Date date = dateFormat.parse(dateTime);
				
				dateFormat = new SimpleDateFormat(destPattern, locale);
				dateFormat.setTimeZone(TimeZone.getTimeZone(CalendarManager.TIME_ZONE));
				resultDate = dateFormat.format(date);
			}
		}
		catch (Exception e) {
		}
		
		return resultDate;
	}
	
	public static long periodInMillisec(Date currDate, Date pastDate) {
		long periodMillisec = 0L;
		
		if (currDate != null && pastDate != null) {
			long currMillisec = currDate.getTime();
			long pastMillisec = pastDate.getTime();
			
			periodMillisec = currMillisec - pastMillisec;
		}
		
		return periodMillisec;
	}
	
	public static long periodInMillisec(Calendar currCalendar, Calendar pastCalendar) {
		long periodMillisec = 0L;
		
		if (currCalendar != null && pastCalendar != null) {
			long currMillisec = currCalendar.getTimeInMillis();
			long pastMillisec = pastCalendar.getTimeInMillis();
			
			periodMillisec = currMillisec - pastMillisec;
		}
		
		return periodMillisec;
	}
	
	public static Period getPeriod(Calendar startDate, Calendar endDate) {
		LocalDate startLocalDate = CalendarManager.calendarToLocalDate(startDate);
		LocalDate endLocalDate = CalendarManager.calendarToLocalDate(endDate);
		
		return Period.between(startLocalDate, endLocalDate);
	}
	
	public static Duration getDuration(Calendar startDate, Calendar endDate) {
		LocalDateTime startDateTime = CalendarManager.calendarToLocalDateTime(startDate);
		LocalDateTime endDateTime = CalendarManager.calendarToLocalDateTime(endDate);
		
		return Duration.between(startDateTime, endDateTime);
	}
	
	public static double calculateOverSLAPerDays(Calendar currCalendar, Calendar pastCalendar) {
		double overSLADays = 0.0d;
		
		if (currCalendar != null && pastCalendar != null) {
			long periodMillisec = CalendarManager.periodInMillisec(currCalendar, pastCalendar);
			overSLADays = ((double)periodMillisec) / CalendarManager.DAY_IN_MILLISEC;
		}
		
		return overSLADays;
	}
	
}