package th.co.truecorp.crmdev.util.common.bean;

public interface Constants {
	
	// Properties File
	public static final String ENVIRONMENT_BUNDLE	= "th.co.truecorp.crmdev.util.common.resource.EnvironmentBundle";
	public static final String CONFIGURE_BUNDLE 	= "th.co.truecorp.crmdev.util.common.resource.ConfigurationBundle";
	
	public static final String MESSAGE_BUNDLE     	= "th.co.truecorp.crmdev.util.common.resource.MessageBundle";
	public static final String SYSTEM_CODE_BUNDLE 	= "th.co.truecorp.crmdev.util.common.resource.SystemCodeBundle";
	public static final String MODULE_CODE_BUNDLE 	= "th.co.truecorp.crmdev.util.common.resource.ModuleCodeBundle";
	public static final String ERROR_CODE_BUNDLE  	= "th.co.truecorp.crmdev.util.common.resource.ErrorCodeBundle";
}