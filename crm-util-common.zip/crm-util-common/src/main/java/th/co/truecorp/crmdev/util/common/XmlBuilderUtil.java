package th.co.truecorp.crmdev.util.common;

/**
 * 
 * @author Aisun
 *
 */
public class XmlBuilderUtil {
	
	public static String node(String name) {
		StringBuilder builder = new StringBuilder();
		builder.append("<").append(name).append(">");
		return builder.toString();
	}

	public static String node(String name, String value) {
		StringBuilder builder = new StringBuilder();
		
		if (value != null) {
			if ("%CLEAR%".equals(value)) {
				value = "";
			}
			
			builder.append("<").append(name).append(">").append(escapeXml(value)).append("</").append(name).append(">");
		}
		
		return builder.toString();
	}
	
	private static String escapeXml(String value) {
		if (value != null) {
			value = value.replaceAll("&", "&amp;").replaceAll(">", "&gt;").replaceAll("<", "&lt;").replaceAll("\"", "&quot;").replaceAll("'", "&apos;");
		}
		
	    return value;
	}
}