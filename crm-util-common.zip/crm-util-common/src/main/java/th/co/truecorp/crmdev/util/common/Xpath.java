package th.co.truecorp.crmdev.util.common;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Xpath {
	
	Document doc = null;
	
	public Xpath(String xml) throws ParserConfigurationException, SAXException, IOException {
		InputStream input = null;
		
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			
			input = new ByteArrayInputStream(xml.getBytes("UTF-8"));
			doc = builder.parse(input);
		}
		finally {
			if (input != null) {
				input.close();
			}
		}
	}
	
	public String getVal(String path) throws XPathExpressionException {
		XPath xpath = XPathFactory.newInstance().newXPath();
		XPathExpression expr = xpath.compile(path);
		return  (String) expr.evaluate(doc, XPathConstants.STRING);
	}
	
	public String getVal(Node node, String path) throws XPathExpressionException {
		XPath xpath = XPathFactory.newInstance().newXPath();
		XPathExpression expr = xpath.compile(path);
		return  (String) expr.evaluate(node, XPathConstants.STRING);
	}
	
	public Node getNode(String path) throws XPathExpressionException {
		XPath xpath = XPathFactory.newInstance().newXPath();
		XPathExpression expr = xpath.compile(path);
		return (Node) expr.evaluate(doc, XPathConstants.NODE);
	}
	
	public NodeList getList(String path) throws XPathExpressionException {
		XPath xpath = XPathFactory.newInstance().newXPath();
		XPathExpression expr = xpath.compile(path);
		return (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
	}
	
	public String getAttr(Node node, String attrName) {
		return node.getAttributes().getNamedItem(attrName).getNodeValue();
	}
	
	public String getXml() throws TransformerFactoryConfigurationError, TransformerException {
		return getXml(doc);
	}
	
	public void removeNode(String path) throws XPathExpressionException {
		XPath xpath = XPathFactory.newInstance().newXPath();
		XPathExpression expr = xpath.compile(path);
		Node node = (Node) expr.evaluate(doc, XPathConstants.NODE);
		if (node != null) {
			Node parNode = node.getParentNode();
			parNode.removeChild(node);
		}
	}
	
	public String getXml(Node node) throws TransformerFactoryConfigurationError, TransformerException {
		String s = null;
		StringWriter writer = new StringWriter();
		
		try {
	        DOMSource source = new DOMSource(node);
	        StreamResult result = new StreamResult(writer);
	        
	        Properties props = new Properties();
	        props.put(OutputKeys.METHOD, "xml");
	        props.put(OutputKeys.OMIT_XML_DECLARATION, "yes");
	        
	        Transformer transformer = TransformerFactory.newInstance().newTransformer();
	        transformer.setOutputProperties(props);
	        transformer.transform(source, result);
	        
	        s = new String(writer.toString());
		}
		finally {
			try {
				writer.close(); 
			}
			catch (Exception e) {}
		}
        
        return s;
	}
}