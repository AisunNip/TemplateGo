package th.co.truecorp.crmdev.util.common;

import java.util.UUID;

/**
 *
 * @author Paravit T.
 * 
 */
public class UUIDManager {

    public static UUID getUUID() {
        return UUID.randomUUID();
    }

    public static String getTransactionID() {
        return "[TransID_" + UUID.randomUUID().toString() + "] ";
    }
}