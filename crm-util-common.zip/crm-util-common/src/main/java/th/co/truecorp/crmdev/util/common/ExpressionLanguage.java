package th.co.truecorp.crmdev.util.common;

import java.util.LinkedHashMap;

import org.apache.commons.jexl3.JexlBuilder;
import org.apache.commons.jexl3.JexlContext;
import org.apache.commons.jexl3.JexlEngine;
import org.apache.commons.jexl3.JexlExpression;
import org.apache.commons.jexl3.JexlScript;
import org.apache.commons.jexl3.MapContext;

/**
*
* @author Paravit T.
* 
*/
public class ExpressionLanguage {
	
	public Object evaluateExpression(LinkedHashMap<String, Object> variable, String expression) {
		JexlEngine jexl = new JexlBuilder().create();
		JexlExpression jexlExp = jexl.createExpression(expression);
		
		// Create a context and add data
	    JexlContext jexlContext = new MapContext();
	    
	    if (variable != null) {
	    	for (String key : variable.keySet()) {
	    		jexlContext.set(key, variable.get(key));
	    	}
	    }
		
	    return jexlExp.evaluate(jexlContext);
	}
	
	public Object executeScript(LinkedHashMap<String, Object> variable, String scriptText) {
		JexlEngine jexl = new JexlBuilder().create();
		JexlScript script = jexl.createScript(scriptText);
		
		// Create a context and add data
	    JexlContext jexlContext = new MapContext();
	    
	    if (variable != null) {
	    	for (String key : variable.keySet()) {
	    		jexlContext.set(key, variable.get(key));
	    	}
	    }
	    
	    return script.execute(jexlContext);
	}
}