package th.co.truecorp.crmdev.util.common.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Hashtable;

public class LDAPInfo implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private String distinguishedName;
	private String commonName;
	private String givenName;
	private String surname;
	private Hashtable<String, ArrayList<Object>> attributesHash;
	
	public LDAPInfo() {
	}

	public String getDistinguishedName() {
		return distinguishedName;
	}

	public void setDistinguishedName(String distinguishedName) {
		this.distinguishedName = distinguishedName;
	}

	public String getCommonName() {
		return commonName;
	}

	public void setCommonName(String commonName) {
		this.commonName = commonName;
	}

	public String getGivenName() {
		return givenName;
	}

	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public Hashtable<String, ArrayList<Object>> getAttributesHash() {
		return attributesHash;
	}

	public void setAttributesHash(Hashtable<String, ArrayList<Object>> attributesHash) {
		this.attributesHash = attributesHash;
	}
}