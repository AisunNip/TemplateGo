package th.co.truecorp.crmdev.util.common;

import java.text.MessageFormat;
import java.util.ResourceBundle;

public class MessageManager {
	
	private static MessageManager instance;
	private String baseName;
	
	private MessageManager() {
	}
	
	public static synchronized MessageManager getInstance() {
		if (instance == null) {
			instance = new MessageManager();
		}
		
		return instance;
	}
	
	public String getBaseName() {
		return baseName;
	}

	public void setBaseName(String baseName) {
		this.baseName = baseName;
	}
	
	public String createMessage(String code, Object objValue[]) {
		String message = null;
		
		ResourceBundle rb = ResourceBundle.getBundle(this.baseName);
		String messagePattern = rb.getString(code);
		MessageFormat mf = new MessageFormat(messagePattern);
		message = mf.format(objValue);
		
		return message;
	}
	
	public String createMessageByPattern(String messagePattern, Object objValue[]) {
		String message = null;
		
		MessageFormat mf = new MessageFormat(messagePattern);
		message = mf.format(objValue);
		
		return message;
	}

	public String createMessage(String code, String value) {
		Object objValue[] = new Object[1];
		objValue[0] = value;
		return this.createMessage(code, objValue);
	}

	public String createMessage(String code) {
		String message = null;
		
		ResourceBundle rb = ResourceBundle.getBundle(this.baseName);
		message = rb.getString(code);
		
		return message;
	}
}