package th.co.truecorp.crmdev.util.common.bean;

import java.io.Serializable;

public class BackendInfo implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String serviceName;
	private String methodName;
	private String errorCode;
	private String errorMessage;
	
	public BackendInfo() {
	}

	public BackendInfo(String serviceName, String methodName, String errorCode, String errorMessage) {
		this.serviceName = serviceName;
		this.methodName = methodName;
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getMethodName() {
		return methodName;
	}

	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
}