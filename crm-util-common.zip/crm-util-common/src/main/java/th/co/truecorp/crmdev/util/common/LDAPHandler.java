package th.co.truecorp.crmdev.util.common;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.ResourceBundle;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import th.co.truecorp.crmdev.util.common.bean.Constants;
import th.co.truecorp.crmdev.util.common.bean.LDAPInfo;

/**
*
* @author Paravit T.
* Connection Pooling is configured and maintained per Java runtime.
* 	-Dcom.sun.jndi.ldap.connect.pool.debug=fine
*	-Dcom.sun.jndi.ldap.connect.pool.authentication=simple
*	-Dcom.sun.jndi.ldap.connect.pool.protocol=ssl
*	-Dcom.sun.jndi.ldap.connect.pool.maxsize=20
*	-Dcom.sun.jndi.ldap.connect.pool.prefsize=2
*	-Dcom.sun.jndi.ldap.connect.pool.timeout=120000
*/
public class LDAPHandler {
	
	private Logger logger;

	/* serverType = LDAP | ActiveDirectory */
	private String serverType;
	private InitialLdapContext ldapContext;
	
	private String initialContextFactory;
	private String securityAuthentication;
	private boolean isConnectionPool;
	private int connectTimeout;
	private int readTimeout;
	private String ldapReferral;
	private String ldapURL;
	private String ldapVersion;
	private String ldapUserName;
	private String ldapPassword;
	private String baseDC;
	private String userSuffix;
	private String groupSuffix;
	
//	private String trustStore;
//	private String trustStorePassword;
//	private String keyStore;
//	private String keyStorePassword;
	
	public LDAPHandler() {
		this.logger = LogManager.getLogger(LDAPHandler.class);
		this.serverType = "LDAP";
	}
	
	public void loadConfiguration() {
		// Initial LDAP value
		ResourceBundle rb = ResourceBundle.getBundle(Constants.ENVIRONMENT_BUNDLE);
        String environment = null;
        
        if ("LDAP".equalsIgnoreCase(this.serverType)) {
        	environment = rb.getString("Environment") + ".LDAPHandler.";
        }
        else {
        	environment = rb.getString("Environment") + ".ActiveDirectory.";
        }
        
        rb = ResourceBundle.getBundle(Constants.CONFIGURE_BUNDLE);
		
		this.initialContextFactory = rb.getString(environment + "InitialContextFactory");
		this.securityAuthentication = rb.getString(environment + "SecurityAuthentication");
		this.isConnectionPool = Boolean.valueOf(rb.getString(environment + "IsConnectionPool")).booleanValue();
		this.connectTimeout = Integer.parseInt(rb.getString(environment + "ConnectTimeout"));
		this.readTimeout = Integer.parseInt(rb.getString(environment + "ReadTimeout"));
		this.ldapReferral = rb.getString(environment + "LDAP_Referral");
		this.ldapURL = rb.getString(environment + "LDAP_URL");
		this.ldapVersion = rb.getString(environment + "LDAP_Version");
//		this.ldapUserName = rb.getString(environment + "LDAP_UserName");
//		this.ldapPassword = rb.getString(environment + "LDAP_Password");
		this.baseDC = rb.getString(environment + "BaseDC");
		this.userSuffix = rb.getString(environment + "UserSuffix");
		this.groupSuffix = rb.getString(environment + "GroupSuffix");
		
		// Initial Certification File
//		this.trustStore = rb.getString(environment + "TrustStore");
//		this.trustStorePassword = rb.getString(environment + "TrustStorePassword");
//		this.keyStore = rb.getString(environment + "KeyStore");
//		this.keyStorePassword = rb.getString(environment + "KeyStorePassword");
	}
	
	/**
	 * 
	 * @return Hashtable
	 * @throws IOException 
	 */
	public Hashtable<String, String> getLDAPEnvironment() throws IOException {
		
		this.logger.info("Begin getLDAPEnvironment");
		
		this.loadConfiguration();
		
		Hashtable<String, String> ldapEnv = new Hashtable<String, String>();
		ldapEnv.put("java.naming.ldap.version", this.ldapVersion);		
		ldapEnv.put(Context.INITIAL_CONTEXT_FACTORY, this.initialContextFactory);
		ldapEnv.put(Context.PROVIDER_URL, this.ldapURL);
		ldapEnv.put(Context.REFERRAL, this.ldapReferral);
		
		ldapEnv.put(Context.SECURITY_AUTHENTICATION, this.securityAuthentication);
		ldapEnv.put(Context.SECURITY_PRINCIPAL, this.ldapUserName);
		ldapEnv.put(Context.SECURITY_CREDENTIALS, this.ldapPassword);
		
		// Specify attributes to be returned in binary format.
		ldapEnv.put("java.naming.ldap.attributes.binary", "userPassword");
		
		if (this.ldapURL.startsWith("ldaps://")) {
			// Secure Socket Layer (SSL) protocol. 
			ldapEnv.put(Context.SECURITY_PROTOCOL, "ssl");
			
			// Set Java Option on WebSphere
//			System.setProperty("javax.net.ssl.trustStore", this.trustStore);
//			System.setProperty("javax.net.ssl.trustStorePassword", this.trustStorePassword);
//			System.setProperty("javax.net.ssl.keyStore", this.keyStore);
//			System.setProperty("javax.net.ssl.keyStorePassword", this.keyStorePassword);
		}
		
		// Connection Pooling since Java SE 1.4.1
		if (this.isConnectionPool()) {
			ldapEnv.put("com.sun.jndi.ldap.connect.pool", "true");
		}
		
		// A read timeout can be configured for the Sun JNDI/LDAP Service Provider since Java SE 6.
		ldapEnv.put("com.sun.jndi.ldap.read.timeout", String.valueOf(this.readTimeout));
		ldapEnv.put("com.sun.jndi.ldap.connect.timeout", String.valueOf(this.connectTimeout));
		
		return ldapEnv;
	}
	
	/**
	 * 
	 * @param scope such as ONELEVEL, SUBTREE
	 * @return SearchControls object.
	 */
	public SearchControls getSearchControls(String scope) {
		SearchControls controls = new SearchControls();
		
		if ("ONELEVEL".equalsIgnoreCase(scope)) {
			controls.setSearchScope(SearchControls.ONELEVEL_SCOPE);
		}
		else {
			controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
		}
		
		return controls;
	}
	
	/**
	 * 
	 * @param userName
	 * 		- Case LDAP use "uid=paravit, ou=Employees, cn=users, dc=truecorp, dc=co, dc=th"
	 * 		- Case Active Directory use "paravit@true.th"
	 * @param password
	 * @throws NamingException
	 * @throws IOException
	 */
	public void authenticate(String userName, String password, boolean isAppendBaseDN)
		throws NamingException, IOException {
		
		DirContext dirContext = null;
		
		try {
			if (isAppendBaseDN) {
				this.ldapUserName = userName + "," + this.userSuffix + "," + this.baseDC;
			}
			else {
				this.ldapUserName = userName;
			}
			
			this.ldapPassword = password;
			
			Hashtable<String, String> ldapEnv = this.getLDAPEnvironment();
			dirContext = new InitialDirContext(ldapEnv);
		}
		finally {
			if (dirContext != null) {
				// Close the LDAP connection.
				dirContext.close();
				dirContext = null;
			}
		}
	}
	
	/**
	 * 
	 * @param dn
	 * @param scope such as ONELEVEL, SUBTREE
	 * @param filterExpr - the filter expression to use for the search; may not be null
	 * 		There are three logical operators that can be used in filters: AND (&), OR (|), and NOT (!).
	 * @throws IOException
	 * @throws NamingException
	 */
	public LDAPInfo search(String dn, String scope, String filterExpr) throws IOException, NamingException {
		LDAPInfo ldapInfo = new LDAPInfo();
		DirContext dirContext = null;
		
		try {
			SearchControls searchCtrls = this.getSearchControls(scope);
			
			Hashtable<String, String> ldapEnv = this.getLDAPEnvironment();
			dirContext = new InitialDirContext(ldapEnv);
			
			NamingEnumeration<SearchResult> namingEnum = dirContext.search(dn, filterExpr, searchCtrls);

		    while (namingEnum.hasMore()) {
		    	SearchResult searchResult = (SearchResult) namingEnum.next();
		    	ldapInfo.setDistinguishedName(searchResult.getName());
		    	
		    	// get the attributes and attribute list
				Attributes attributes = searchResult.getAttributes();
				NamingEnumeration<?> attributesEnum = attributes.getAll();
				
				Hashtable<String, ArrayList<Object>> attributesHash = new Hashtable<String, ArrayList<Object>>();
				
				// while we have attributes
				while (attributesEnum.hasMore()) {
					Attribute attr = (Attribute)attributesEnum.next();
					String attributeName = attr.getID();
					
					// Get the attribute's values
					NamingEnumeration<?> valuesEnum = attr.getAll();
					
					while (valuesEnum.hasMore()) {
						Object attributeValue = valuesEnum.next();
						
						if ("cn".equalsIgnoreCase(attributeName) || "commonName".equalsIgnoreCase(attributeName)) {
							ldapInfo.setCommonName(attributeValue.toString());
						}
						else if ("givenName".equalsIgnoreCase(attributeName)) {
							ldapInfo.setGivenName(attributeValue.toString());
						}
						else if ("sn".equalsIgnoreCase(attributeName) || "surname".equalsIgnoreCase(attributeName)) {
							ldapInfo.setSurname(attributeValue.toString());  
						}
						else {
							ArrayList<Object> attributeValueList = attributesHash.get(attributeName);
							if (attributeValueList == null) {
								attributeValueList = new ArrayList<Object>();
							}
							
							attributeValueList.add(attributeValue);
							
							attributesHash.put(attributeName, attributeValueList);
						}
					}
				}
				
				if (!attributesHash.isEmpty()) {
					ldapInfo.setAttributesHash(attributesHash);
				}
		    }
		}
		finally {
			if (dirContext != null) {
				// Close the LDAP connection.
				dirContext.close();
				dirContext = null;
			}
		}
		
		return ldapInfo;
	}
	
	public String getServerType() {
		return serverType;
	}

	public void setServerType(String serverType) {
		this.serverType = serverType;
	}

	public InitialLdapContext getLdapContext() {
		return ldapContext;
	}

	public void setLdapContext(InitialLdapContext ldapContext) {
		this.ldapContext = ldapContext;
	}

	public String getInitialContextFactory() {
		return initialContextFactory;
	}

	public void setInitialContextFactory(String initialContextFactory) {
		this.initialContextFactory = initialContextFactory;
	}

	public String getSecurityAuthentication() {
		return securityAuthentication;
	}

	public void setSecurityAuthentication(String securityAuthentication) {
		this.securityAuthentication = securityAuthentication;
	}
	
	public boolean isConnectionPool() {
		return isConnectionPool;
	}

	public void setConnectionPool(boolean isConnectionPool) {
		this.isConnectionPool = isConnectionPool;
	}
	
	public int getConnectTimeout() {
		return connectTimeout;
	}

	public void setConnectTimeout(int connectTimeout) {
		this.connectTimeout = connectTimeout;
	}

	public int getReadTimeout() {
		return readTimeout;
	}

	public void setReadTimeout(int readTimeout) {
		this.readTimeout = readTimeout;
	}

	public String getLdapReferral() {
		return ldapReferral;
	}

	public void setLdapReferral(String ldapReferral) {
		this.ldapReferral = ldapReferral;
	}

	public String getLdapURL() {
		return ldapURL;
	}

	public void setLdapURL(String ldapURL) {
		this.ldapURL = ldapURL;
	}

	public String getLdapVersion() {
		return ldapVersion;
	}

	public void setLdapVersion(String ldapVersion) {
		this.ldapVersion = ldapVersion;
	}

	public String getLdapUserName() {
		return ldapUserName;
	}

	public void setLdapUserName(String ldapUserName) {
		this.ldapUserName = ldapUserName;
	}

	public String getLdapPassword() {
		return ldapPassword;
	}

	public void setLdapPassword(String ldapPassword) {
		this.ldapPassword = ldapPassword;
	}

	public String getBaseDC() {
		return baseDC;
	}

	public void setBaseDC(String baseDC) {
		this.baseDC = baseDC;
	}

	public String getUserSuffix() {
		return userSuffix;
	}

	public void setUserSuffix(String userSuffix) {
		this.userSuffix = userSuffix;
	}

	public String getGroupSuffix() {
		return groupSuffix;
	}

	public void setGroupSuffix(String groupSuffix) {
		this.groupSuffix = groupSuffix;
	}
}