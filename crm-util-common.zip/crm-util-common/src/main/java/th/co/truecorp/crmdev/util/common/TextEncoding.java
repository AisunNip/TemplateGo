package th.co.truecorp.crmdev.util.common;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.NumberFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Properties;
import java.util.Random;
import java.util.Set;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
*
* @author Paravit T.
* 
*/
public class TextEncoding {
	
	// String literals
	public static final String BACKSPACE = "\b";
	public static final String TAB = "\t";
	public static final String LINE_FEED = "\n";
	public static final String CARRIAGE_RETURN = "\r";
	public static final String FORM_FEED = "\f";
	public static final String DOUBLE_QUOTE = "\"";
	public static final String SINGLE_QUOTE = "\'";
	public static final String BACKSLASH = "\\";
	
	// ASCII Code
	public static final String ASCII_CR = "0x0D";
	public static final String ASCII_LF = "0x0A";
	
	// The byte order mark (BOM) is a Unicode character.
	public static final String UTF8_BOM = "\uFEFF";
	
	public static String getEndOfLine() {
		return System.getProperty("line.separator");
	}
	
	public static String exceptionToString(Throwable t) {
        String errorMessage = null;
        
        if (t != null) {
            errorMessage = t.toString();
            StackTraceElement[] traceElements = t.getStackTrace();
            for (int i = 0; i < traceElements.length; i++) {
                errorMessage += TextEncoding.getEndOfLine() + traceElements[i].toString();
            }
        }

        return errorMessage;
    }
	
	public static String decodeEnter(String data) {
		if (data != null && !"".equals(data)) {
			data = data.replaceAll(ASCII_CR, CARRIAGE_RETURN);
			data = data.replaceAll(ASCII_LF, LINE_FEED);
		}
		
		return data;
	}
	
	public static String removeEnter(String data) {
		if (data != null && !"".equals(data)) {
			data = data.replaceAll("\n", "");
			data = data.replaceAll("\r", "");
			data = data.replaceAll("\f", "");
		}
		
		return data;
	}
	
	public static String encodeURL(String url, Properties queryString) throws UnsupportedEncodingException {
		String encodeURL = null;
		
		if (queryString != null && queryString.size() > 0) {
			int countQueryString = 0;
			StringBuilder queryBuilder = new StringBuilder("?");
			
			Set<Object> queryStringSet = queryString.keySet();
    		Iterator<Object> iterator = queryStringSet.iterator();
			
    		while (iterator.hasNext()) {
				countQueryString++;
				
				String queryName = (String)iterator.next();
				String queryValue = (String)queryString.get(queryName);
				queryValue = URLEncoder.encode(queryValue, "UTF-8");
				
				if (countQueryString > 1) {
					queryBuilder.append("&");
				}
				
				queryBuilder.append(queryName);
				queryBuilder.append("=");
				queryBuilder.append(queryValue);
			}
			
			encodeURL = url + queryBuilder.toString();
		}
		else {
			encodeURL = url;
		}
		
		return encodeURL;
	}
	
	/**
	 * 
	 * @param unicode UTF-16 such as "\\u63A8\\u85A6\\u865F\\u78BC"
	 * @return
	 */
	public static String utf16ToString(String unicode) {
		String result = null;
		
		if (unicode != null) {
			String unicodePrefix = "\\u005C\\u0075";
			String[] unicodeList = unicode.split(unicodePrefix);
			
			StringBuilder text = new StringBuilder();
			for (int i = 1; i < unicodeList.length; i++) {
			    int hexVal = Integer.parseInt(unicodeList[i], 16);
			    text.append((char)hexVal);
			}
			
			result = text.toString();
		}
		
		return result;
	}
	
	public static String stringToHTMLDecimal(String data) {
		String result = null;
		
		if (data != null) {
			StringBuilder text = new StringBuilder();
			
			for (int i = 0; i < data.length(); i++) {
				text.append("&#");
				text.append((int)data.charAt(i));
				text.append(";");
			}
			
			result = text.toString();
		}
		
		return result;
	}
	
	public static String unicodeToASCII(String unicode) {
		StringBuffer ascii = new StringBuffer(unicode);
		
		int code;
		for (int i = 0; i < unicode.length(); i++) {
			code = (int) unicode.charAt(i);
			if ((0xE01 <= code) && (code <= 0xE5B))
				ascii.setCharAt(i, (char) (code - 0xD60));
		}
		
		return ascii.toString();
	}

	public static String asciiToUnicode(String ascii) {
		StringBuffer unicode = new StringBuffer(ascii);
		
		int code;
		for (int i = 0; i < ascii.length(); i++) {
			code = (int) ascii.charAt(i);
			if ((0xA1 <= code) && (code <= 0xFB))
				unicode.setCharAt(i, (char) (code + 0xD60));
		}
		
		return unicode.toString();
	}
	
	public static String encodeBASE64(String data) {
		
		String base64 = null;
		
		if (data != null) {
			BASE64Encoder base64Encoder = new BASE64Encoder();
			base64 = base64Encoder.encode(data.getBytes());
		}
		
		return base64;
	}
    
    public static String decodeBASE64(String data) throws IOException {
    	
    	String plainText = null;
    	
    	if (data != null) {
    		BASE64Decoder base64Decoder = new BASE64Decoder();
    		plainText = new String(base64Decoder.decodeBuffer(data));
    	}
    	
    	return plainText;
    }
    
	/**
	 * @param CDATA must be encode as following.
	 * 	&lt; < less than
	 * 	&gt; > greater than
	 *  &amp; & ampersand
	 *  &apos; ' apostrophe
	 *  &quot; " quotation mark
	 * @return a string
	 */
	public static String encodeXML(String CDATA) {
		if (CDATA != null) {
			CDATA = CDATA.replaceAll("&", "&amp;");
			CDATA = CDATA.replaceAll("<", "&lt;");
			CDATA = CDATA.replaceAll(">", "&gt;");
			CDATA = CDATA.replaceAll("'", "&apos;");
			CDATA = CDATA.replaceAll("\"", "&quot;");
		}
		
		return CDATA;
	}
	
	public static String decodeXML(String CDATA) {
		if (CDATA != null) {
			CDATA = CDATA.replaceAll("&amp;", "&");
			CDATA = CDATA.replaceAll("&lt;", "<");
			CDATA = CDATA.replaceAll("&gt;", ">");
			CDATA = CDATA.replaceAll("&apos;", "'");
			CDATA = CDATA.replaceAll("&quot;", "\"");
		}
		
		return CDATA;
	}
	
	public static String[] splitEnter(String data) {
		String result[] = null;
		
		if (data != null) {
			result = data.split("\r\n|\r|\n");
		}
		
		return result;
	}
	
	public static String removeSymbols(String data) {
		if (data != null) {
			// UTF-8 Symbols 
			// NUMERAL [\\u2150-\\u218F]
			String regularExpression = "([\\u2000-\\u206F]|[\\u20A0-\\u20CF]|[\\u2100-\\u214F]|[\\u2190-\\u22FF]|[\\u2500-\\u27BF])";
			data = data.replaceAll(regularExpression, "");
		}
		
		return data;
	}
	
	public static String removeWhitespace(String data) {
		if (data != null) {
			data = data.replaceAll("\\s", "");
		}
		
		return data;
	}
	
	public static String nullToString(Object obj) {
		if (obj == null) {
			return new String();
		}
		else {
			return obj.toString();
		}
	}
	
	public static String stringToNull(String data) {
		if ("null".equalsIgnoreCase(data)) {
			return null;
		}
		else {
			return data;
		}
	}
	
	public static boolean stringToBoolean(String data) {
		boolean result = false;
		
		if ("true".equalsIgnoreCase(data) || "y".equalsIgnoreCase(data)) {
			result = true;
		}
		
		return result;
	}
	
	public static String blankToNull(String data) {
		if ("".equalsIgnoreCase(data)) {
			return null;
		}
		else {
			return data;
		}
	}
	
	public static String insertAtPosition(String data, int position, String insertMessage) {
		if (data == null) {
			return data;
		}
		
		if (insertMessage == null || "".equals(insertMessage)) {
	        return data;
	    }
		
		StringBuffer resultBuffer = new StringBuffer(data);
		resultBuffer.insert(position, insertMessage);
		return resultBuffer.toString();
	}
	
	public static double currencyToDouble(String currency) {
		double resultCurrency = 0.00d;
		
		if (currency != null) {
			currency = currency.trim();
			if (!"".equals(currency)) {
				currency = currency.replaceAll(",", "");
				resultCurrency = Double.parseDouble(currency);
			}
		}
		
		return resultCurrency;
	}
	
	/**
	 * NumberFormat uses half-even rounding (see ROUND_HALF_EVEN) for formatting.
	 * @param decimal number
	 * @return String
	 */
	public static String formatDecimal(double decimalNumber) {
		NumberFormat formatter = NumberFormat.getNumberInstance();
		formatter.setMinimumFractionDigits(2);
		formatter.setMaximumFractionDigits(2);
		formatter.setGroupingUsed(false);
		
		return formatter.format(decimalNumber);
	}
	
	/**
	 * NumberFormat uses half-even rounding (see ROUND_HALF_EVEN) for formatting.
	 * @param decimal number
	 * @return String
	 */
	public static String formatDecimalByComma(double decimalNumber) {
		NumberFormat formatter = NumberFormat.getNumberInstance();
		formatter.setMinimumFractionDigits(2);
		formatter.setMaximumFractionDigits(2);
		formatter.setGroupingUsed(true);
		
		return formatter.format(decimalNumber);
	}
	
	public static String formatIntegerByComma(double decimalNumber) {
		NumberFormat formatter = NumberFormat.getNumberInstance();
		formatter.setMinimumFractionDigits(0);
		formatter.setMaximumFractionDigits(0);
		formatter.setGroupingUsed(true);
		
		return formatter.format(decimalNumber);
	}
	
	/**
	 * 
	 * @param overSLA
	 * @return String in format Days:Hours
	 */
	public static String formatOverSLAPerDays(double overSLA) {
		String strOverSLA = String.valueOf(overSLA);
		String dayHour[] = strOverSLA.split("\\.");
		double days = Double.parseDouble(dayHour[0]);
		double hours = Double.parseDouble("0." + dayHour[1]) * 24;
		
		strOverSLA = TextEncoding.formatIntegerByComma(days) + ":"
				   + TextEncoding.formatDecimalByComma(hours);
		
		return strOverSLA;
	}
	
	public static String formatJSONString(String val) {	
		String result = "";
		
		if (val == null) {
			result = null;
		}
		else if("".equals(val)) {
			result = "\"\"";
		}
		else {
			char data[] = val.toCharArray();
			
			for(int index = 0; index < data.length; index++) {
				char chrData = data[index];
				if(chrData == '\"')	{
					// Found Quatation Mark.
					result = result + "\\" + String.valueOf(chrData);
				}
				else if(chrData == '\r') {
					// Found carriage return
					result = result + "\\r";
				}
				else if(chrData == '\n') {
					// Found newline.
					result = result + "\\n";
				}
				else {
					result = result + String.valueOf(chrData);
				}
			}
			
			result = "\"" + result + "\"";
		}
		
		return result;
	}
	
	/**
	 * 
	 * @return Unique Key as format yyyyMMddHHmmssSSS-Random 5 digit
	 * @throws InterruptedException
	 */
	public static synchronized String generateUniqueKey() throws InterruptedException {
		Thread.sleep(10);
		
		Calendar currCalendar = CalendarManager.getEngCalendar();
		String dateTime = CalendarManager.calendarToString(currCalendar, "yyyyMMddHHmmssSSS", CalendarManager.LOCALE_EN);
		
		Random random = new Random();
		int randomNo = random.nextInt(99999);
		String randomNo5Digits = String.format("%05d", randomNo);
		
		return dateTime + "-" + randomNo5Digits;
	}
}