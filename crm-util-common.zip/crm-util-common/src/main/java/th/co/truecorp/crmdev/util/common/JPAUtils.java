package th.co.truecorp.crmdev.util.common;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 * 
 * JPA utilities used Bean Manage Persistence.
 * @author Paravit T.
 * 
 */
public class JPAUtils {
	
	public JPAUtils() {
	}

	public void persist(String persistUnitName, Object entityObj) {
		EntityManagerFactory entityManagerFactory = null;
		EntityManager entityManager = null;
		
		try {
			entityManagerFactory = Persistence.createEntityManagerFactory(persistUnitName);
			entityManager = entityManagerFactory.createEntityManager();
			
			EntityTransaction entityTrans = entityManager.getTransaction();
			entityTrans.begin();
			entityManager.persist(entityObj);
			entityTrans.commit();
		}
		finally {
			if (entityManager != null) {
				entityManager.close();
			}
			
			if (entityManagerFactory != null) {
				entityManagerFactory.close();
			}
		}
	}
	
	public void remove(String persistUnitName, Class<?> classObj, Object entityPK) {
		EntityManagerFactory entityManagerFactory = null;
		EntityManager entityManager = null;
		
		try {
			entityManagerFactory = Persistence.createEntityManagerFactory(persistUnitName);
			entityManager = entityManagerFactory.createEntityManager();
			
			EntityTransaction entityTrans = entityManager.getTransaction();
			entityTrans.begin();
			
			Object entityObj = entityManager.find(classObj, entityPK);
			if (entityObj != null) {
				entityManager.remove(entityObj);
			}
			
			entityTrans.commit();
		}
		finally {
			if (entityManager != null) {
				entityManager.close();
			}
			
			if (entityManagerFactory != null) {
				entityManagerFactory.close();
			}
		}
	}
}