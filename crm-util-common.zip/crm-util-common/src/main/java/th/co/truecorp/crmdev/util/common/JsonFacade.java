package th.co.truecorp.crmdev.util.common;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

/**
*
* @author Paravit T.
* Jackson 2.14.1 compatible with JDK 1.8
* 
*/
public class JsonFacade<T> {

	private Class<T> entityClass;
	private ObjectMapper objMapper;
    
    public JsonFacade(Class<T> entityClass) {
        this.entityClass = entityClass;
        
        this.objMapper = new ObjectMapper();
        this.objMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ"));
        this.objMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		this.objMapper.setSerializationInclusion(Include.NON_NULL);
    }
    
    public void enableFeature(SerializationFeature feature) {
    	if (this.objMapper != null) {
    		this.objMapper.enable(feature);
    	}
    }
    
    public void disableFeature(DeserializationFeature feature) {
    	if (this.objMapper != null) {
    		this.objMapper.disable(feature);
    	}
    }
    
    public JsonNode readTree(String json) throws JsonProcessingException, IOException {
    	return this.objMapper.readTree(json);
    }
    
    public JsonNode readTree(InputStream is) throws JsonProcessingException, IOException {
    	return this.objMapper.readTree(is);
    }
    
	public String objectToString(T entity) throws JsonProcessingException {
		return this.objMapper.writeValueAsString(entity);
	}
	
	public T stringToObject(String json) 
		throws JsonParseException, JsonMappingException, IOException {
		return this.objMapper.readValue(json, this.entityClass);
	}
	
	public void writeToFile(String jsonFileName, T entity) 
		throws JsonGenerationException, JsonMappingException, IOException {
		
		this.objMapper.writeValue(new File(jsonFileName), entity);
	}
	
	public T readFileToObject(String jsonFileName) 
		throws JsonParseException, JsonMappingException, IOException  {
		
		return this.objMapper.readValue(new File(jsonFileName), this.entityClass);
	}
}