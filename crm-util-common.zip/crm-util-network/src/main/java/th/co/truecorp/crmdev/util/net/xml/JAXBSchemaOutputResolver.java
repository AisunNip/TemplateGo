package th.co.truecorp.crmdev.util.net.xml;

import java.io.File;
import java.io.IOException;

import javax.xml.bind.SchemaOutputResolver;
import javax.xml.transform.Result;
import javax.xml.transform.stream.StreamResult;

/**
 * 
 * @author Paravit T.
 *
 */
public class JAXBSchemaOutputResolver extends SchemaOutputResolver {
	
	private String suggestedFileName;	
	
	public String getSuggestedFileName() {
		return suggestedFileName;
	}

	public void setSuggestedFileName(String suggestedFileName) {
		this.suggestedFileName = suggestedFileName;
	}

	@Override
	public Result createOutput(String namespaceUri, String suggestedFileName) throws IOException {
		return new StreamResult(new File(".", this.suggestedFileName));
	}
}