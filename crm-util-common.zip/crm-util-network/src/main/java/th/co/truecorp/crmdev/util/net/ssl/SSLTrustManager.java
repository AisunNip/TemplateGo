package th.co.truecorp.crmdev.util.net.ssl;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
*
* @author Paravit T.
* 
*/
public class SSLTrustManager implements X509TrustManager {
	
	@Override
	public void checkClientTrusted(X509Certificate[] chain, String authType)
		throws CertificateException {
	}

	@Override
	public void checkServerTrusted(X509Certificate[] chain, String authType)
		throws CertificateException {
	}

	@Override
	public X509Certificate[] getAcceptedIssuers() {
		return null;
	}
	
	public SSLContext getSSLContext()
		throws NoSuchAlgorithmException, KeyManagementException {
		// To force accepting all certificates.
        SSLContext sslContext = SSLContext.getInstance("SSL"); // "SSL" or "TLS"
        sslContext.init(null, new TrustManager[]{this}, new SecureRandom());
        return sslContext;
	}
	
	public SSLSocketFactory getSSLSocketFactory()
		throws NoSuchAlgorithmException, KeyManagementException {
        SSLContext sslContext = this.getSSLContext();
        SSLSocketFactory sslSocketFactory = (SSLSocketFactory) sslContext.getSocketFactory();
        return sslSocketFactory;
	}
}