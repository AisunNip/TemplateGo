package th.co.truecorp.crmdev.util.net.rest;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.TimeUnit;

import org.jboss.resteasy.client.jaxrs.ResteasyClient;
import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder;

import th.co.truecorp.crmdev.util.net.ssl.AllowAllHostnameVerifier;
import th.co.truecorp.crmdev.util.net.ssl.SSLTrustManager;

public class RestEasyUtil {

	private Boolean isBypassSSL;
	
	// connectTimeout in milliseconds.
	private Long connectTimeout;
	
	// readTimeout in milliseconds.
	private Long readTimeout;
	
	public RestEasyUtil() {
		this.isBypassSSL = Boolean.FALSE;
		this.connectTimeout = new Long(5000);
		this.readTimeout = new Long(60000);
	}
	
	public Boolean getIsBypassSSL() {
		return isBypassSSL;
	}

	public void setIsBypassSSL(Boolean isBypassSSL) {
		this.isBypassSSL = isBypassSSL;
	}
	
	public Long getConnectTimeout() {
		return connectTimeout;
	}

	public void setConnectTimeout(Long connectTimeout) {
		this.connectTimeout = connectTimeout;
	}

	public Long getReadTimeout() {
		return readTimeout;
	}

	public void setReadTimeout(Long readTimeout) {
		this.readTimeout = readTimeout;
	}
	
	/**
	 * 
	 * @return Client object.
	 * 
	 * Ex. 	RestEasyUtil restEasyUtil = new RestEasyUtil();
	 *		ResteasyClient client = restEasyUtil.newClientRESTEasy();
	 *		ResteasyWebTarget webTarget = client.target("url");
	 * @throws NoSuchAlgorithmException 
	 * @throws KeyManagementException 
	 */
	public ResteasyClient newClientRESTEasy() throws KeyManagementException, NoSuchAlgorithmException {
		ResteasyClientBuilder clientBuilder = new ResteasyClientBuilder();
		
		if (this.getIsBypassSSL()) {
			SSLTrustManager sslTrustManager = new SSLTrustManager();
			clientBuilder.sslContext(sslTrustManager.getSSLContext());
			clientBuilder.hostnameVerifier(new AllowAllHostnameVerifier());
		}
		
		if (this.getConnectTimeout() != null) {
			clientBuilder.connectTimeout(this.getConnectTimeout().longValue(), TimeUnit.MILLISECONDS);
		}
		
		if (this.getReadTimeout() != null) {
			clientBuilder.readTimeout(this.getReadTimeout().longValue(), TimeUnit.MILLISECONDS);
		}
		
		return clientBuilder.build();
	}
}