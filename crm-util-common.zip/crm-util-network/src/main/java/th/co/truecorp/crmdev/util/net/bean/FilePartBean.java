package th.co.truecorp.crmdev.util.net.bean;

import java.io.File;

public class FilePartBean {

	private String fieldName;
	private File file;
	private String fileName;
	
	public FilePartBean() {
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
}