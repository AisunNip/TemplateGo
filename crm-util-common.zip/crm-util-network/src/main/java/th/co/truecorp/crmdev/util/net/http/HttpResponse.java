package th.co.truecorp.crmdev.util.net.http;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class HttpResponse implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private int httpStatusCode;
	private String httpStatusMsg;
	private Map<String, List<String>> httpHeader;
	private String responseText;
	private boolean isRedirect;
	private String redirectURL;
	
	public HttpResponse() {
	}

	public int getHttpStatusCode() {
		return httpStatusCode;
	}

	public void setHttpStatusCode(int httpStatusCode) {
		this.httpStatusCode = httpStatusCode;
	}

	public String getHttpStatusMsg() {
		return httpStatusMsg;
	}

	public void setHttpStatusMsg(String httpStatusMsg) {
		this.httpStatusMsg = httpStatusMsg;
	}

	public Map<String, List<String>> getHttpHeader() {
		return httpHeader;
	}

	public void setHttpHeader(Map<String, List<String>> httpHeader) {
		this.httpHeader = httpHeader;
	}

	public String getResponseText() {
		return responseText;
	}

	public void setResponseText(String responseText) {
		this.responseText = responseText;
	}

	public boolean isRedirect() {
		return isRedirect;
	}

	public void setRedirect(boolean isRedirect) {
		this.isRedirect = isRedirect;
	}

	public String getRedirectURL() {
		return redirectURL;
	}

	public void setRedirectURL(String redirectURL) {
		this.redirectURL = redirectURL;
	}
}