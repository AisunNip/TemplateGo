package th.co.truecorp.crmdev.util.net.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Properties;

/**
 *
 * @author Paravit T.
 * 
 */
public class XMLProperties implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
    private String tagName;
    private Properties attribute;
    private String textNode;
    private ArrayList<XMLProperties> childNode;

    public XMLProperties() {
        this.childNode = new ArrayList<XMLProperties>();
    }
    
    public XMLProperties(String tagName, Properties attribute, String textNode, ArrayList<XMLProperties> childNode) {
        this.tagName = tagName;
        this.attribute = attribute;
        this.textNode = textNode;
        this.childNode = childNode;
    }

    public int getChildCount() {
        return this.childNode.size();
    }

    public XMLProperties[] getChildNodes() {
        XMLProperties xmlProperties[] = null;
        
        if (this.getChildCount() > 0) {
            xmlProperties = (XMLProperties[])this.childNode.toArray(new XMLProperties[0]);
        }

        return xmlProperties;
    }
    
    public void appendChildNode(XMLProperties xmlProp) {
        this.childNode.add(xmlProp);
    }

    public void removeChildNode(int index) {
        this.childNode.remove(index);
    }

    public Properties getAttribute() {
        return attribute;
    }

    public void setAttribute(Properties attribute) {
        this.attribute = attribute;
    }

    public String getTagName() {
        return tagName;
    }

    public void setTagName(String tagName) {
        this.tagName = tagName;
    }

    public String getTextNode() {
        return textNode;
    }

    public void setTextNode(String textNode) {
        this.textNode = textNode;
    }
}