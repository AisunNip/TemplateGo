package th.co.truecorp.crmdev.util.net.xml;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

/**
 * 
 * @author Paravit T.
 * 
 */
public class JAXBManager {
	
	/*
		This will generate a set of Java classes annotated with JAXB 2.0 annotations
		xjc OrderStatusBN.xsd -d src
	*/
	
	private Boolean formattedOutput;
	
	public JAXBManager() {
		this.formattedOutput = Boolean.FALSE;
	}

	public Boolean getFormattedOutput() {
		return formattedOutput;
	}

	public void setFormattedOutput(Boolean formattedOutput) {
		this.formattedOutput = formattedOutput;
	}

	public String objectToXMLString(Object obj, Class<?> type) throws JAXBException {
    	StringWriter stringWriter = new StringWriter();
    	
    	// Instantiate a JAXBContext object
    	JAXBContext context = JAXBContext.newInstance(type);
    	// Create a Marshaller object that can be used to convert a java content tree into XML data.
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
        marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, this.getFormattedOutput());
        marshaller.marshal(obj, stringWriter);
        
        return stringWriter.toString();
	}
    
    public Object xmlStringToObject(String xml, Class<?> type) throws JAXBException {
    	StringReader reader = new StringReader(xml);
    	
    	// Instantiate a JAXBContext object
    	JAXBContext context = JAXBContext.newInstance(type);
    	// Create an Unmarshaller object that can be used to convert XML data into a java content tree.
    	Unmarshaller unMarshaller = context.createUnmarshaller();
    	
    	return unMarshaller.unmarshal(reader);
    }
    
    /**
     * Generates the schema documents (.xsd file)
     * @param type
     * @throws JAXBException
     * @throws IOException
     */
    public void generateSchema(Class<?> type) throws JAXBException, IOException {
    	JAXBSchemaOutputResolver schemaOutputResolver = new JAXBSchemaOutputResolver();
    	schemaOutputResolver.setSuggestedFileName(type.getName() + ".xsd");
    	
    	JAXBContext context = JAXBContext.newInstance(type);
    	context.generateSchema(schemaOutputResolver);
    }
}