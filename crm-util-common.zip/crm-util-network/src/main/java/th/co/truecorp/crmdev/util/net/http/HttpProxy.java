package th.co.truecorp.crmdev.util.net.http;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.SocketException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import th.co.truecorp.crmdev.util.common.TextEncoding;
import th.co.truecorp.crmdev.util.common.UUIDManager;
import th.co.truecorp.crmdev.util.common.Validator;
import th.co.truecorp.crmdev.util.net.bean.ProxyBean;
import th.co.truecorp.crmdev.util.net.ssl.AllowAllHostnameVerifier;
import th.co.truecorp.crmdev.util.net.ssl.SSLTrustManager;
import th.co.truecorp.crmdev.util.net.xml.XMLManager;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 
 * HttpProxy for xml, web service
 * 
 * @author Paravit T.
 * 
 * Configure in "web.xml" Default load a configuration file from "/WEB-INF/HttpProxy.xml"
 * <context-param>
 * 		<param-name>th.co.truecorp.crmdev.util.http.HttpProxy.CONFIG_FILE_NAME</param-name>
 * 		<param-value>/data/appcfg/HttpProxy.xml</param-value>
 * </context-param>
 * 
 * HttpProxy.xml
 * <HttpProxy connectTimeout="5000" readTimeout="60000">
 * 		<ProxyServer domainName="" hostName="proxy.true.th" portNo="80" userName="" password="" />
 * 		<Host requestPath="/SendIt" destinationURL="https://api.staging.sendit.asia" 
 * 			connectTimeout="5000" readTimeout="40000" thruProxyServer="Y" />
 * 		<Host requestPath="/TrueAppGateway" destinationURL="http://172.19.136.92" 
 * 			connectTimeout="5000" readTimeout="30000" thruProxyServer="N" />
 * </HttpProxy>
 * 
 */
public class HttpProxy extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

    private final String HTTP_HEADER_NAME_HOST = "Host";
    
    private Logger logger;
    
    private ProxyBean proxyBean;
    private XMLManager xmlManager;
    private Validator validator;
    
    private Document proxyConfig;
    private int defaultConnectTimeout;
    private int defaultReadTimeout;

    @Override
    public String getServletInfo() {
        return "HttpProxy";
    }
    
    @Override
    public void init(ServletConfig servletConfig) throws ServletException {
    	this.logger = LogManager.getLogger(HttpProxy.class);
    	
    	this.xmlManager = new XMLManager();
    	this.validator = new Validator();
    	this.setDefaultConnectTimeout(5000);
    	this.setDefaultReadTimeout(60000);
    }
    
    private void setProxyAuthorization(HttpURLConnection httpConn
	   	, String domainName, String userName, String password)
	   	throws IOException {
		    	
    	if (httpConn != null && userName != null && password != null) {
            String proxyAuthorization = null;
            if (domainName != null) {
                 proxyAuthorization = new String(domainName + "\\" + userName + ":" + password);
            }
            else {
                 proxyAuthorization = new String(userName + ":" + password);
            }
            
    		httpConn.setRequestProperty("Proxy-Connection", "Keep-Alive");
    		httpConn.setRequestProperty("Proxy-Authorization", "Basic " + TextEncoding.encodeBASE64(proxyAuthorization));
    	}
    }
    
    public HttpURLConnection openHttpConnection(Element hostElement, String url) 
    	throws IOException {
    	
		HttpURLConnection httpConn = null;
		
        String connectTimeout = hostElement.getAttribute("connectTimeout");
        String readTimeout = hostElement.getAttribute("readTimeout");
        String thruProxyServer = hostElement.getAttribute("thruProxyServer");
		
		URL targetURL = new URL(url);
    	
    	if ("Y".equalsIgnoreCase(thruProxyServer) && this.proxyBean != null) {
    		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(this.proxyBean.getProxyIP(), this.proxyBean.getProxyPort()));
    		
    		if (url.startsWith("https")) {
    			httpConn = (HttpsURLConnection)targetURL.openConnection(proxy);
    		}
    		else {
    			httpConn = (HttpURLConnection)targetURL.openConnection(proxy);
    		}
    		
    		if (this.proxyBean.getProxyUserName() != null && this.proxyBean.getProxyPassword() != null) {
    			this.setProxyAuthorization(httpConn, this.proxyBean.getDomainName()
    									, this.proxyBean.getProxyUserName(), this.proxyBean.getProxyPassword());
    		}
    	}
    	else {
    		if (url.startsWith("https")) {
    			httpConn = (HttpsURLConnection)targetURL.openConnection();
    		}
    		else {
    			httpConn = (HttpURLConnection)targetURL.openConnection();
    		}
    	}
    	
    	httpConn.setDoInput(true);
    	httpConn.setDoOutput(true);
    	httpConn.setUseCaches(false);
    	httpConn.setAllowUserInteraction(true);
        httpConn.setInstanceFollowRedirects(true);
    	
    	if (this.validator.hasStringValue(connectTimeout)) {
        	httpConn.setConnectTimeout(Integer.parseInt(connectTimeout));
        }
        else {
        	httpConn.setConnectTimeout(this.getDefaultConnectTimeout());
        }
        
        if (this.validator.hasStringValue(readTimeout)) {
        	httpConn.setReadTimeout(Integer.parseInt(readTimeout));
        }
        else {
        	httpConn.setReadTimeout(this.getDefaultReadTimeout());
        }
    	
    	return httpConn;
	}
	
    @Override
	protected void service(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException {
		
    	HttpURLConnection httpConn = null;
        String transID = null;
        long startTime = 0L;
        
        try {
        	startTime = System.currentTimeMillis();
            transID = UUIDManager.getTransactionID();
            this.logger.info(transID + "##### Begin HttpProxy.service() #####");
            
            this.loadHttpProxyConfig(request, transID);
            
            byte[] requestBinaryData = null;
            
            if (!"GET".equalsIgnoreCase(request.getMethod()) && request.getContentLength() > 0) {
            	requestBinaryData = this.readData(request.getInputStream());
            	this.logger.debug(transID + "Request Message: " + new String(requestBinaryData));
            }
            
            Element hostElement = this.getProxyConfigByRequestPath(request, transID);
            
            String destURL = this.getDestinationURL(request, hostElement, transID);
            
            if (destURL.startsWith("https")) {
            	// Bypass SSL
            	SSLTrustManager sslTrustManager = new SSLTrustManager();
		    	HttpsURLConnection.setDefaultSSLSocketFactory(sslTrustManager.getSSLSocketFactory());
		    	HttpsURLConnection.setDefaultHostnameVerifier(new AllowAllHostnameVerifier());
            }
            
            httpConn = this.openHttpConnection(hostElement, destURL);
            httpConn.setRequestMethod(request.getMethod());
            
            this.logger.info(transID + "URL: " + destURL + ", HttpMethod: " + request.getMethod() 
            				+ ", ConnectTimeout: " + httpConn.getConnectTimeout() 
            				+ ", ReadTimeout: " + httpConn.getReadTimeout());
            
            // Set Request HTTP Headers to destination.
            this.setHttpHeaderRequest(request, httpConn, destURL, transID);

            httpConn.connect();
            this.logger.debug(transID + "Destination Connected Successfully.");
            
            if (requestBinaryData != null) {
            	this.sendData(httpConn.getOutputStream(), requestBinaryData);
            }

            int httpStatusCode = httpConn.getResponseCode();
            String httpStatusMsg = httpConn.getResponseMessage();
            this.logger.debug(transID + "Destination Return HttpStatusCode: " + httpStatusCode + ", HttpStatusMsg: " + httpStatusMsg);
            
            byte[] responseBinaryData = null;
            
            if (httpStatusCode >= 200 && httpStatusCode < 400) {
            	// Get HTTP Body - Read data from destination.
                responseBinaryData = this.readData(httpConn.getInputStream());
            }
            else {
            	responseBinaryData = this.readData(httpConn.getErrorStream());
            }
            this.logger.debug(transID + "Read Data From Destination Successfully.");
            
            response.setStatus(httpStatusCode);
            this.setHttpHeaderResponse(response, httpConn, transID);
            this.sendData(response.getOutputStream(), responseBinaryData);
        }
        catch (SocketException sockEx) {
            try {
            	String errorMessage = "Destination Accessing Error: " + sockEx.getMessage();
            	this.logger.error(transID + errorMessage, sockEx);
            	
            	response.sendError(HttpServletResponse.SC_GATEWAY_TIMEOUT, errorMessage);
            }
            catch (Exception e) {
            }
        }
        catch (Throwable t) {
            try {
            	String errorMessage = "HttpProxy Internal Error: " + t.getMessage();
            	this.logger.error(transID + errorMessage, t);
            	
            	response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, errorMessage);
            }
            catch (Exception e) {
            }
        }
        finally {
            if (httpConn != null) {
                httpConn.disconnect();
                httpConn = null;
            }
            
            this.logger.info(transID + "ResponseTime: " + (System.currentTimeMillis() - startTime) + " ms.");
            this.logger.info(transID + "##### End HttpProxy.service() #####");
        }
    }
    
    public void loadHttpProxyConfig(HttpServletRequest request, String transID) throws Exception {
    	try {
    		if (this.proxyConfig == null) {
    			String paramName = HttpProxy.class.getName() + ".CONFIG_FILE_NAME";
    			
    			ServletContext context = request.getServletContext();
    			String configFileName = context.getInitParameter(paramName);
    			
    			if (configFileName == null) {
    				configFileName = context.getRealPath("/WEB-INF/HttpProxy.xml");
    			}
    			
    			this.logger.debug(transID + "configFileName: " + configFileName);
    					
    			if (configFileName == null) {
    				throw new Exception("HttpProxy not found a configuration file.");
    			}
    			
		    	this.proxyConfig = this.xmlManager.readXMLFile(configFileName);
		    	
		    	String connectTimeout = this.xmlManager.queryXPath("/HttpProxy/@connectTimeout", this.proxyConfig);
		    	
		    	if (this.validator.hasStringValue(connectTimeout)) {
		    		this.setDefaultConnectTimeout(Integer.parseInt(connectTimeout));
		    	}
		    	
		    	String readTimeout = this.xmlManager.queryXPath("/HttpProxy/@readTimeout", this.proxyConfig);
		    	
		    	if (this.validator.hasStringValue(readTimeout)) {
		    		this.setDefaultReadTimeout(Integer.parseInt(readTimeout));
		    	}
		    	
		    	// Proxy Server
		    	Node proxyServerNode = this.xmlManager.queryXPathNode("/HttpProxy/ProxyServer", this.proxyConfig);
		        Element proxyServerElem = this.xmlManager.nodeToElement(proxyServerNode);
		        
		        if (proxyServerElem != null) {
		        	this.proxyBean = new ProxyBean();
		        	
		        	if (this.validator.hasStringValue(proxyServerElem.getAttribute("domainName"))) {
		        		this.proxyBean.setDomainName(proxyServerElem.getAttribute("domainName"));
		        	}
		        	
		        	if (this.validator.hasStringValue(proxyServerElem.getAttribute("hostName"))) {
		        		this.proxyBean.setProxyIP(proxyServerElem.getAttribute("hostName"));
		        	}
		        	
		        	if (this.validator.hasStringValue(proxyServerElem.getAttribute("portNo"))) {
		        		this.proxyBean.setProxyPort(Integer.parseInt(proxyServerElem.getAttribute("portNo")));
		        	}
		        	
		        	if (this.validator.hasStringValue(proxyServerElem.getAttribute("userName"))) {
		        		this.proxyBean.setProxyUserName(proxyServerElem.getAttribute("userName"));
		        	}
		        	
		        	if (this.validator.hasStringValue(proxyServerElem.getAttribute("password"))) {
		        		this.proxyBean.setProxyPassword(proxyServerElem.getAttribute("password"));
		        	}
		        }
    		}
    	}
    	catch (Throwable t) {
    		this.logger.error(transID + t.getMessage(), t);
    		throw new Exception(t.getMessage());
    	}
    }
    
    /**
     * 
     * @return value of http header "Host"
     * 
     */
    public String getHttpHeaderHost(String url) throws MalformedURLException {
    	
    	String hostName = null;
    	
    	URL urlObj = new URL(url);
    	
    	if (urlObj.getPort() == -1) {
    		hostName = urlObj.getHost();
    	}
    	else {
    		hostName = urlObj.getHost() + ":" + urlObj.getPort();
    	}
    	
    	return hostName;
    }

    private byte[] readData(InputStream inputStream) throws IOException {
    	byte[] binary = null;
    	
    	if (inputStream != null) {
	    	byte[] readBuffer = new byte[1024];
	        ByteArrayOutputStream byteOuts = new ByteArrayOutputStream();
	        while (true) {
	            int count = inputStream.read(readBuffer);
	            if (count == -1) {
	                break;
	            }
	            byteOuts.write(readBuffer, 0, count);
	        }
	        inputStream.close();
	        inputStream = null;
	        
	        binary = byteOuts.toByteArray();
    	}
        
        return binary;
    }
    
    private void sendData(OutputStream outputStream, byte[] binaryData) throws IOException {
        outputStream.write(binaryData);
    	outputStream.flush();
    	outputStream.close();
    	outputStream = null;
    }
    
    private Element getProxyConfigByRequestPath(HttpServletRequest request, String transID) throws Exception {
    	String requestURI = request.getRequestURI();
        String contextPath = request.getContextPath();
        this.logger.debug(transID + "URI: " + request.getRequestURI() + ", ContextPath: " + contextPath);
        
        String realURI = requestURI.replaceFirst(contextPath, "");
        
        // Find RequestPath
        int beginIndex = realURI.indexOf("/");
		int endIndex = realURI.indexOf("/", beginIndex + 1);
		if (endIndex == -1) {
			endIndex = realURI.length();
		}
		String requestPath = realURI.substring(beginIndex, endIndex);
        
        // Find routing path.
        NodeList nodeList = this.xmlManager.queryXPathNodeList("/HttpProxy/Host[@requestPath='" + requestPath + "']", this.getProxyConfig());
        Element[] hostElem = xmlManager.nodeListToElement(nodeList);
        
        if (hostElem == null) {
        	throw new Exception("HttpProxy's configuration not found this request path (" + requestPath + ")");
        }
        
        return hostElem[0];
    }
    
    private String getDestinationURL(HttpServletRequest request, Element hostElement, String transID) 
    	throws Exception {
    	
    	String requestPath = hostElement.getAttribute("requestPath");
        String destinationURL = hostElement.getAttribute("destinationURL");
        this.logger.debug(transID + "RequestPath: " + requestPath + ", DestinationURL: " + destinationURL);
        
        String requestURI = request.getRequestURI();
        String contextPath = request.getContextPath();
        String queryString = request.getQueryString();
        
        String realURI = requestURI.replaceFirst(contextPath, "");
        realURI = realURI.replaceFirst(requestPath, "");
	    
        StringBuilder destURL = new StringBuilder();
        destURL.append(destinationURL);
        destURL.append(realURI);
        
        if (queryString != null) {
             destURL.append("?");
             destURL.append(queryString);
        }
        
        return destURL.toString();
    }
    
    private void setHttpHeaderRequest(HttpServletRequest request, HttpURLConnection httpConn, String url, String transID)
    	throws MalformedURLException {
    	
    	this.logger.debug(transID + "##### Begin HttpProxy.setHttpHeaderRequest() #####");
    	
        Enumeration<String> enumHeaderName = request.getHeaderNames();
        while (enumHeaderName.hasMoreElements()) {
            String headerName = (String)enumHeaderName.nextElement();
            
            if (HTTP_HEADER_NAME_HOST.equalsIgnoreCase(headerName)) {
                httpConn.setRequestProperty(headerName, this.getHttpHeaderHost(url));
                this.logger.debug(transID + headerName + ": " + this.getHttpHeaderHost(url));
            }
            else if ("$WSCS".equalsIgnoreCase(headerName)
            		|| "$WSIS".equalsIgnoreCase(headerName)
            		|| "$WSSC".equalsIgnoreCase(headerName)
            		|| "$WSPR".equalsIgnoreCase(headerName)
            		|| "$WSRA".equalsIgnoreCase(headerName)
            		|| "$WSRH".equalsIgnoreCase(headerName)
            		|| "$WSRU".equalsIgnoreCase(headerName)
            		|| "$WSSN".equalsIgnoreCase(headerName)
            		|| "$WSSP".equalsIgnoreCase(headerName)
            		|| "$WSSI".equalsIgnoreCase(headerName)
            		|| "$WSFO".equalsIgnoreCase(headerName)) {
            	this.logger.debug(transID + "Filter Out WebSphere Header >>> " + headerName + ": " + request.getHeader(headerName));
            }
            else {
                httpConn.setRequestProperty(headerName, request.getHeader(headerName));
                this.logger.debug(transID + headerName + ": " + request.getHeader(headerName));
            }
        }
        
        this.logger.debug(transID + "##### End HttpProxy.setHttpHeaderRequest() #####");
    }
    
    private void setHttpHeaderResponse(HttpServletResponse response, HttpURLConnection httpConn, String transID) {
    	// Get Response HTTP Header
        this.logger.debug(transID + "##### Begin HttpProxy.setHttpHeaderResponse() #####");
        
        boolean isGZIPEncoding = false;
        Iterator headerIterator = httpConn.getHeaderFields().entrySet().iterator();
        
        while (headerIterator.hasNext()) {
            Map.Entry mapEntry = (Map.Entry)headerIterator.next();
            
            if (mapEntry.getKey() != null) {
                String headerName = mapEntry.getKey().toString();
                String headerValue = ((List)mapEntry.getValue()).get(0).toString();
                
                if ("Transfer-Encoding".equalsIgnoreCase(headerName) && "chunked".equalsIgnoreCase(headerValue)) {
                	// Apache Axis 1.4 support http version 1.0 only.
                	continue;
                }
                
                if ("Content-Encoding".equalsIgnoreCase(headerName) && "gzip".equalsIgnoreCase(headerValue)) {
                    isGZIPEncoding = true;
                }

                response.setHeader(headerName, headerValue);
                this.logger.debug(transID + headerName + ": " + headerValue);
            }
        }
        
        this.logger.debug(transID + "##### End HttpProxy.setHttpHeaderResponse() #####");
    }

	public Document getProxyConfig() {
		return proxyConfig;
	}

	public void setProxyConfig(Document proxyConfig) {
		this.proxyConfig = proxyConfig;
	}

	public int getDefaultConnectTimeout() {
		return defaultConnectTimeout;
	}

	public void setDefaultConnectTimeout(int defaultConnectTimeout) {
		this.defaultConnectTimeout = defaultConnectTimeout;
	}

	public int getDefaultReadTimeout() {
		return defaultReadTimeout;
	}

	public void setDefaultReadTimeout(int defaultReadTimeout) {
		this.defaultReadTimeout = defaultReadTimeout;
	}
}