package th.co.truecorp.crmdev.util.net.http;

import java.io.BufferedReader;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

public class HttpUtil {

	public HttpUtil() {
	}

	public String getRequestURL(HttpServletRequest httpRequest) {
		return httpRequest.getRequestURL().toString();
	}

	public String getInitParameter(HttpServletRequest request, String paramName) {
		ServletContext context = request.getServletContext();
		return context.getInitParameter(paramName);
	}

	public String getRequestBody(HttpServletRequest httpRequest) {
		StringBuilder body = new StringBuilder();
		BufferedReader bufferedReader = null;
		
		try {
			if (!"GET".equalsIgnoreCase(httpRequest.getMethod())) {
				
				bufferedReader = httpRequest.getReader();
				char[] charBuffer = new char[256];
				int bytesRead;
				
				while ((bytesRead = bufferedReader.read(charBuffer)) != -1) {
					body.append(charBuffer, 0, bytesRead);
				}
			}
		}
		catch (Exception ex) {
		}
		finally {
			try {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
			}
			catch (Exception ex2) {
			}
		}
		
		return body.toString();
	}
}