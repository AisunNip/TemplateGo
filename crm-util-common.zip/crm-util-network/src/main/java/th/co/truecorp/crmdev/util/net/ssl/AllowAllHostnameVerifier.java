package th.co.truecorp.crmdev.util.net.ssl;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

/**
*
* @author Paravit T.
* 
*/
public class AllowAllHostnameVerifier implements HostnameVerifier {

	@Override
	public boolean verify(String hostName, SSLSession session) {
		return true;
	}
}