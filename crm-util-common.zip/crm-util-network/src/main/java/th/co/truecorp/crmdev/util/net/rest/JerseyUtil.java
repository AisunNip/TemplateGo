package th.co.truecorp.crmdev.util.net.rest;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.media.multipart.MultiPartFeature;

import th.co.truecorp.crmdev.util.net.ssl.AllowAllHostnameVerifier;
import th.co.truecorp.crmdev.util.net.ssl.SSLTrustManager;

public class JerseyUtil {

	private Boolean isBypassSSL;
	
	// connectTimeout in milliseconds.
	private Integer connectTimeout;
	
	// readTimeout in milliseconds.
	private Integer readTimeout;
	
	public JerseyUtil() {
		this.isBypassSSL = Boolean.FALSE;
		this.connectTimeout = new Integer(5000);
		this.readTimeout = new Integer(60000);
	}
	
	public Boolean getIsBypassSSL() {
		return isBypassSSL;
	}

	public void setIsBypassSSL(Boolean isBypassSSL) {
		this.isBypassSSL = isBypassSSL;
	}

	public Integer getConnectTimeout() {
		return connectTimeout;
	}

	public void setConnectTimeout(Integer connectTimeout) {
		this.connectTimeout = connectTimeout;
	}

	public Integer getReadTimeout() {
		return readTimeout;
	}

	public void setReadTimeout(Integer readTimeout) {
		this.readTimeout = readTimeout;
	}
	
	/**
	 * 
	 * @return Client object.
	 * Ex. 	JerseyUtil jerseyUtil = new JerseyUtil();
	 *		Client client = jerseyUtil.newClientJersey();
	 *		WebTarget webTarget = client.target("url");
	 * @throws NoSuchAlgorithmException 
	 * @throws KeyManagementException 
	 */
	public Client newClientJersey() throws KeyManagementException, NoSuchAlgorithmException {
		ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		
		if (Boolean.TRUE.equals(this.getIsBypassSSL())) {
			SSLTrustManager sslTrustManager = new SSLTrustManager();
			clientBuilder.sslContext(sslTrustManager.getSSLContext());
			clientBuilder.hostnameVerifier(new AllowAllHostnameVerifier());
		}
		
		clientBuilder.register(MultiPartFeature.class);
		Client client = clientBuilder.build();
		
		if (this.getConnectTimeout() != null) {
			client.property(ClientProperties.CONNECT_TIMEOUT, this.getConnectTimeout());
		}
		
		if (this.getReadTimeout() != null) {
			client.property(ClientProperties.READ_TIMEOUT, this.getReadTimeout());
		}
		
		return client;
	}
}