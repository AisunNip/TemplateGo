package th.co.truecorp.crmdev.util.net.ssh;

public class SshException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public SshException() {
		super();
	}

	public SshException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public SshException(String message, Throwable cause) {
		super(message, cause);
	}

	public SshException(String message) {
		super(message);
	}

	public SshException(Throwable cause) {
		super(cause);
	}

}