package th.co.truecorp.crmdev.util.net.http;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;

import javax.net.ssl.HttpsURLConnection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import th.co.truecorp.crmdev.util.common.TextEncoding;
import th.co.truecorp.crmdev.util.common.UUIDManager;
import th.co.truecorp.crmdev.util.net.bean.FilePartBean;
import th.co.truecorp.crmdev.util.net.bean.ProxyBean;
import th.co.truecorp.crmdev.util.net.ssl.AllowAllHostnameVerifier;
import th.co.truecorp.crmdev.util.net.ssl.SSLTrustManager;

public class HttpRequest {

	private Logger logger;
	private Boolean isBypassSSL;
	private ProxyBean proxyBean;
	private String charset;
	// connectTimeout in milliseconds.
    private int connectTimeout;
    // readTimeout in milliseconds.
    private int readTimeout;
    
	public HttpRequest() {
		this.isBypassSSL = Boolean.FALSE;
		this.charset = "UTF-8";
		this.connectTimeout = 5000;
		this.readTimeout = 60000;
		
    	this.logger = LogManager.getLogger(HttpRequest.class);
	}
	
	public Properties generateBasicAuthorization(String userName, String password) 
		throws IOException {
		
		Properties httpHeader = new Properties();
		httpHeader.setProperty("Authorization", "Basic " + TextEncoding.encodeBASE64(userName + ":" + password));
		
		return httpHeader;
	}
	
	private void setProxyAuthorization(HttpURLConnection httpConn
	   	, String domainName, String userName, String password)
	   	throws IOException {
		    	
    	if (httpConn != null && userName != null && password != null) {
            String proxyAuthorization = null;
            
            if (domainName != null) {
                 proxyAuthorization = new String(domainName + "\\" + userName + ":" + password);
            }
            else {
                 proxyAuthorization = new String(userName + ":" + password);
            }
            
    		httpConn.setRequestProperty("Proxy-Connection", "Keep-Alive");
    		httpConn.setRequestProperty("Proxy-Authorization", "Basic " + TextEncoding.encodeBASE64(proxyAuthorization));
    	}
    }
	
	public HttpURLConnection openHttpConnection(String url) throws IOException {
		HttpURLConnection httpConn = null;
		
		URL targetURL = new URL(url);
    	
    	if (this.proxyBean != null) {
    		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(this.proxyBean.getProxyIP(), this.proxyBean.getProxyPort()));
    		
    		if (url.startsWith("https")) {
    			httpConn = (HttpsURLConnection)targetURL.openConnection(proxy);
    		}
    		else {
    			httpConn = (HttpURLConnection)targetURL.openConnection(proxy);
    		}
    		
    		if (this.proxyBean.getProxyUserName() != null 
    			&& this.proxyBean.getProxyPassword() != null) {
    			
    			this.setProxyAuthorization(httpConn, this.proxyBean.getDomainName()
    									, this.proxyBean.getProxyUserName(), this.proxyBean.getProxyPassword());
    		}
    	}
    	else {
    		if (url.startsWith("https")) {
    			httpConn = (HttpsURLConnection)targetURL.openConnection();
    		}
    		else {
    			httpConn = (HttpURLConnection)targetURL.openConnection();
    		}
    	}
    	
    	httpConn.setDoInput(true);
    	httpConn.setDoOutput(true);
    	httpConn.setUseCaches(false);
    	httpConn.setConnectTimeout(this.getConnectTimeout());
    	httpConn.setReadTimeout(this.getReadTimeout());
    	
    	return httpConn;
	}

	/**
	 * 
	 * @param url is mandatory.
	 * @param requestMethod is mandatory. POST, GET
	 * @param httpHeader
	 * 		Ex. Content-Type = text/html | text/xml | text/plain
	 * @param data is optional.
	 * @return HttpResponse
	 * @throws IOException 
	 * @throws NoSuchAlgorithmException 
	 * @throws KeyManagementException 
	 */
	private HttpResponse send(String url, String requestMethod, Properties httpHeader, String data) 
		throws IOException, KeyManagementException, NoSuchAlgorithmException {
		
		HttpResponse httpResp = new HttpResponse();
		String responseText = null;
		HttpURLConnection httpConn = null;
		OutputStream outputStream = null;
    	InputStream inputStream = null;
    	
		try {
    		byte[] binaryData = null;
    		String contentLength = "0";
    		
    		if (data != null) {
    			binaryData = data.getBytes(this.getCharset());
    			contentLength = String.valueOf(binaryData.length);
    		}
	    	
			if (this.isBypassSSL) {
		    	SSLTrustManager sslTrustManager = new SSLTrustManager();
		    	HttpsURLConnection.setDefaultSSLSocketFactory(sslTrustManager.getSSLSocketFactory());
		    	HttpsURLConnection.setDefaultHostnameVerifier(new AllowAllHostnameVerifier());
	    	}
			
			httpConn = this.openHttpConnection(url);
	    	
	    	if (httpHeader != null) {
	    		Set headerNameSet = httpHeader.keySet();
	    		Iterator iterator = headerNameSet.iterator();
				while (iterator.hasNext()) {
					String headerName = (String)iterator.next();
					String headerValue = (String)httpHeader.get(headerName);
					httpConn.setRequestProperty(headerName, headerValue);
				}
	    	}
	    	
	    	httpConn.setRequestMethod(requestMethod);
	    	httpConn.setRequestProperty("Content-Length", contentLength);
	    	
	    	String transID = UUIDManager.getTransactionID();
	    	this.logger.debug(transID + "URL: " + url + "|Http Method: " + requestMethod);
			this.logger.debug(transID + "Request: " + data);
	    	httpConn.connect();
	    	
	    	if (binaryData != null) {
		    	// send data to server.
		    	outputStream = httpConn.getOutputStream();
		    	outputStream.write(binaryData);
		    	outputStream.flush();
	    	}
	    	
	    	// read data
	        if (httpConn.getResponseCode() >= 200 && httpConn.getResponseCode() < 400) {
		    	inputStream = httpConn.getInputStream();
	        }
	        else {
	        	inputStream = httpConn.getErrorStream();
	        }
	        
	        if (inputStream != null) {
		        responseText = new String(this.readInputStream(inputStream), this.getCharset());
		        this.logger.debug(transID + "Response: " + responseText);
	        }
	        
	        int httpStatusCode = httpConn.getResponseCode();
	        httpResp.setHttpStatusCode(httpStatusCode);
	        httpResp.setHttpStatusMsg(httpConn.getResponseMessage());
	        httpResp.setHttpHeader(httpConn.getHeaderFields());
	        httpResp.setResponseText(responseText);
	        
	        if (httpStatusCode == HttpURLConnection.HTTP_MOVED_PERM
	    		|| httpStatusCode == HttpURLConnection.HTTP_MOVED_TEMP
	    		|| httpStatusCode == HttpURLConnection.HTTP_SEE_OTHER) {
	        	httpResp.setRedirect(true);
	        	httpResp.setRedirectURL(httpConn.getHeaderField("Location"));
	        }
	        else {
	        	httpResp.setRedirect(false);
	        }
		}
		finally {
			if (outputStream != null) {
				outputStream.close();
				outputStream = null;
			}
			
			if (inputStream != null) {
				inputStream.close();
				inputStream = null;
			}
			
			if (httpConn != null) {
				httpConn.disconnect();
				httpConn = null;
	        }
		}
		
		return httpResp;
	}
	
	public HttpResponse get(String url, Properties httpHeader)
		throws IOException, KeyManagementException, NoSuchAlgorithmException {
		return this.send(url, "GET", httpHeader, null);
	}
	
	public HttpResponse post(String url, Properties httpHeader, String data)
		throws IOException, KeyManagementException, NoSuchAlgorithmException {
		return this.send(url, "POST", httpHeader, data);
	}
	
	public HttpResponse postXML(String url, Properties httpHeader, String data)
		throws IOException, KeyManagementException, NoSuchAlgorithmException {
		
		if (httpHeader == null) {
			httpHeader = new Properties();
		}
		
		if (this.getCharset() != null && !"".equals(this.getCharset())) {
			httpHeader.setProperty("Content-Type", "text/xml; charset=" + this.getCharset().toLowerCase());
		}
		else {
			httpHeader.setProperty("Content-Type", "text/xml");
		}
		
		return this.send(url, "POST", httpHeader, data);
	}
	
	public HttpResponse postJSON(String url, Properties httpHeader, String data)
		throws IOException, KeyManagementException, NoSuchAlgorithmException {
		
		if (httpHeader == null) {
			httpHeader = new Properties();
		}
		
		if (this.getCharset() != null && !"".equals(this.getCharset())) {
			httpHeader.setProperty("Content-Type", "application/json; charset=" + this.getCharset().toLowerCase());
		}
		else {
			httpHeader.setProperty("Content-Type", "application/json");
		}
		
		return this.send(url, "POST", httpHeader, data);
	}
	
	public HttpResponse postForm(String url, Properties httpHeader, Properties formData)
		throws IOException, KeyManagementException, NoSuchAlgorithmException {
		
		String data = null;
		
		if (formData != null) {
			StringBuilder dataBuilder = new StringBuilder();
			
			Set<Object> controlSet = formData.keySet();
    		Iterator iterator = controlSet.iterator();
			while (iterator.hasNext()) {
				String controlName = (String) iterator.next();
				String controlValue = (String) formData.get(controlName);
				
				dataBuilder.append("&");
				dataBuilder.append(controlName);
				dataBuilder.append("=");
				dataBuilder.append(URLEncoder.encode(controlValue, this.getCharset()));
			}
			
			data = dataBuilder.toString();
			data = data.substring(1);
		}
		
		if (httpHeader == null) {
			httpHeader = new Properties();
		}
		
		if (this.getCharset() != null && !"".equals(this.getCharset())) {
			httpHeader.setProperty("Content-Type", "application/x-www-form-urlencoded; charset=" + this.getCharset().toLowerCase());
		}
		else {
			httpHeader.setProperty("Content-Type", "application/x-www-form-urlencoded");
		}
		
		return this.send(url, "POST", httpHeader, data);
	}
	
	public HttpResponse postMultipartForm(String url, Properties httpHeader
		, Properties formData, ArrayList<FilePartBean> filePartList) 
		throws KeyManagementException, NoSuchAlgorithmException, IOException {
		
		String boundary = UUID.randomUUID().toString();
		boundary = boundary.replaceAll("-", "");
		String lineFeed = "\r\n";
		
		if (httpHeader == null) {
			httpHeader = new Properties();
		}
		
		httpHeader.setProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
		
		StringBuilder dataBuilder = new StringBuilder();
		
		if (formData != null) {
			// Form Field
			Set<Object> controlSet = formData.keySet();
    		Iterator iterator = controlSet.iterator();
			
    		while (iterator.hasNext()) {
				String name = (String) iterator.next();
				String value = (String) formData.get(name);
				
				dataBuilder.append("--" + boundary).append(lineFeed);
				dataBuilder.append("Content-Disposition: form-data; name=\"" + name + "\"");
				dataBuilder.append(lineFeed);
				dataBuilder.append(lineFeed);
				dataBuilder.append(value);
				dataBuilder.append(lineFeed);
			}
		}
		
		// File Part
		if (filePartList != null) {
			for (FilePartBean filePartBean : filePartList) {
				dataBuilder.append("--" + boundary).append(lineFeed);
				dataBuilder.append("Content-Disposition: form-data; name=\"" + filePartBean.getFieldName() 
									+ "\"; filename=\"" + filePartBean.getFileName() + "\"");
				dataBuilder.append(lineFeed);
				dataBuilder.append("Content-Type: application/octet-stream");
				dataBuilder.append(lineFeed);
				dataBuilder.append(lineFeed);
				
				FileInputStream inputStream = new FileInputStream(filePartBean.getFile());
				byte[] binary = this.readInputStream(inputStream);
				
				dataBuilder.append(new String(binary, this.getCharset()));
				dataBuilder.append(lineFeed);
			}
		}
		
		// Final
		dataBuilder.append("--" + boundary + "--");
		dataBuilder.append(lineFeed);
		
		return this.send(url, "POST", httpHeader, dataBuilder.toString());
	}
	
	public byte[] readInputStream(InputStream inputStream) throws IOException {
		byte[] binary = null;

		if (inputStream != null) {
			ByteArrayOutputStream outBuffer = new ByteArrayOutputStream();
			byte[] readBuffer = new byte[2048];

			while (true) {
				int count = inputStream.read(readBuffer);
				if (count == -1)
					break;
				outBuffer.write(readBuffer, 0, count);
			}

			binary = outBuffer.toByteArray();
			readBuffer = null;
			outBuffer.close();
			inputStream.close();
		}

		return binary;
	}
	
	public void displayHttpHeader(Map<String, List<String>> httpHeader) {
		if (httpHeader != null) {
			for (Map.Entry<String, List<String>> entry : httpHeader.entrySet()) {
	    		System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
	    	}
		}
	}
	
	public Logger getLogger() {
		return logger;
	}

	public void setLogger(Logger logger) {
		this.logger = logger;
	}

	public Boolean getIsBypassSSL() {
		return isBypassSSL;
	}

	public void setIsBypassSSL(Boolean isBypassSSL) {
		this.isBypassSSL = isBypassSSL;
	}

	public ProxyBean getProxyBean() {
		return proxyBean;
	}

	public void setProxyBean(ProxyBean proxyBean) {
		this.proxyBean = proxyBean;
	}

	public String getCharset() {
		return charset;
	}

	public void setCharset(String charset) {
		this.charset = charset;
	}

	public int getConnectTimeout() {
		return connectTimeout;
	}

	public void setConnectTimeout(int connectTimeout) {
		this.connectTimeout = connectTimeout;
	}

	public int getReadTimeout() {
		return readTimeout;
	}

	public void setReadTimeout(int readTimeout) {
		this.readTimeout = readTimeout;
	}
}