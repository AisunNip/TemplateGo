package th.co.truecorp.crmdev.util.net.ssh;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

/**
 * 
 * @author Paravit T.
 * JCraft - JSch Java SSH2 implementation
 * SSH File Transfer Protocol (SFTP)
 * 
 */
public class SshClient {

	private JSch jschSSHChannel;
	private String knownHostsFileName;
	private String hostName;
	private int portNo;
	private String userName;
	private String password;
	private Session sshSession;
	private int connectTimeout;
	
	public SshClient() {
		this.portNo = 22;
		this.connectTimeout = 5000;
	}

	public void connect() throws SshException {
		try {
			this.jschSSHChannel = new JSch();
			
			if (this.getKnownHostsFileName() != null) {
				this.jschSSHChannel.setKnownHosts(this.getKnownHostsFileName());
			}
			
			// Creates a new Session.
			this.sshSession = this.jschSSHChannel.getSession(this.getUserName(), this.getHostName(), this.getPortNo());
			this.sshSession.setPassword(this.getPassword());
			
			if (this.getKnownHostsFileName() == null) {
				this.sshSession.setConfig("StrictHostKeyChecking", "no");
			}
			
			// opens the connection
			this.sshSession.connect(this.getConnectTimeout());
		}
		catch (Throwable t) {
			throw new SshException("Could not connect to host name: " 
								+ this.getHostName() + " port no: " + this.getPortNo()
								+ " because " + t.getMessage(), t);
		}
	}
	
	public void disconnect() {
		if (this.sshSession != null) {
			this.sshSession.disconnect();
			this.sshSession = null;
		}
	}

	public String sendCommand(String command) throws SshException {
		String responseText = null;
		ChannelExec channelExec = null;
		InputStream inputStream = null;
		
		try {
			byte[] readBuffer = new byte[1024];
			ByteArrayOutputStream outputBuffer = new ByteArrayOutputStream();
			
			channelExec = (ChannelExec) this.sshSession.openChannel("exec");
			channelExec.setCommand(command);
			inputStream = channelExec.getInputStream();
			channelExec.connect();
			
			while (true) {
				int count = inputStream.read(readBuffer);
				if (count == -1)
					break;
				outputBuffer.write(readBuffer, 0, count);
			}
			
			responseText = new String(outputBuffer.toByteArray());
		}
		catch (Throwable t) {
			throw new SshException("Execute a command occur error because " 
								+ t.getMessage(), t);
		}
		finally {
			try {
				if (inputStream != null) {
					inputStream.close();
					inputStream = null;
				}
				
				if (channelExec != null && channelExec.isConnected()) {
					channelExec.disconnect();
					channelExec = null;
				}
			}
    		catch (Throwable t) {
    		}
		}

		return responseText;
	}
	
	public void uploadFile(String localFileName, String remoteFileName) throws SshException {
		FileInputStream inputStream = null;
		ChannelSftp channelSftp = null;
		
		try {
			inputStream = new FileInputStream(localFileName);
			
			channelSftp = (ChannelSftp) this.sshSession.openChannel("sftp");
			channelSftp.connect();
			
			channelSftp.put(inputStream, remoteFileName, ChannelSftp.OVERWRITE);
		}
		catch (Throwable t) {
			throw new SshException("Could not upload a file to host name: " 
								+ this.getHostName() + " port no: " + this.getPortNo()
								+ " because " + t.getMessage(), t);
		}
		finally {
			try {
				if (inputStream != null) {
	    			inputStream.close();
	    			inputStream = null;
	    		}
				
				if (channelSftp != null && channelSftp.isConnected()) {
					channelSftp.disconnect();
					channelSftp = null;
				}
    		}
    		catch (Throwable t) {
    		}
		}
	}
	
	public void uploadFile(byte[] binary, String remoteFileName) throws SshException {
		ByteArrayInputStream inputStream = null;
		ChannelSftp channelSftp = null;
		
		try {
			inputStream = new ByteArrayInputStream(binary);
			
			channelSftp = (ChannelSftp) this.sshSession.openChannel("sftp");
			channelSftp.connect();
			
			channelSftp.put(inputStream, remoteFileName, ChannelSftp.OVERWRITE);
		}
		catch (Throwable t) {
			throw new SshException("Could not upload a file to host name: " 
								+ this.getHostName() + " port no: " + this.getPortNo()
								+ " because " + t.getMessage(), t);
		}
		finally {
			try {
				if (inputStream != null) {
	    			inputStream.close();
	    			inputStream = null;
	    		}
				
				if (channelSftp != null && channelSftp.isConnected()) {
					channelSftp.disconnect();
					channelSftp = null;
				}
    		}
    		catch (Throwable t) {
    		}
		}
	}
	
	public void downloadFile(String localFileName, String remoteFileName) throws SshException {
		FileOutputStream outputStream = null;
		ChannelSftp channelSftp = null;
		
		try {
			outputStream = new FileOutputStream(localFileName);
			
			channelSftp = (ChannelSftp) this.sshSession.openChannel("sftp");
			channelSftp.connect();
			
			channelSftp.get(remoteFileName, outputStream);
		}
		catch (Throwable t) {
			throw new SshException("Could not download a file from host name: " 
									+ this.getHostName() + " port no: " + this.getPortNo()
									+ " because " + t.getMessage(), t);
		}
		finally {
			try {
				if (outputStream != null) {
					outputStream.close();
					outputStream = null;
	    		}
				
				if (channelSftp != null && channelSftp.isConnected()) {
					channelSftp.disconnect();
					channelSftp = null;
				}
    		}
    		catch (Throwable t) {
    		}
		}
	}
	
	public byte[] downloadFile(String remoteFileName) throws SshException {
		byte[] binary = null;
		ByteArrayOutputStream outputStream = null;
		ChannelSftp channelSftp = null;
		
		try {
			outputStream = new ByteArrayOutputStream();
			
			channelSftp = (ChannelSftp) this.sshSession.openChannel("sftp");
			channelSftp.connect();
			
			channelSftp.get(remoteFileName, outputStream);
			
			binary = outputStream.toByteArray();
		}
		catch (Throwable t) {
			throw new SshException("Could not download a file from host name: " 
									+ this.getHostName() + " port no: " + this.getPortNo()
									+ " because " + t.getMessage(), t);
		}
		finally {
			try {
				if (outputStream != null) {
					outputStream.close();
					outputStream = null;
	    		}
				
				if (channelSftp != null && channelSftp.isConnected()) {
					channelSftp.disconnect();
					channelSftp = null;
				}
    		}
    		catch (Throwable t) {
    		}
		}
		
		return binary;
	}
	
	public String getKnownHostsFileName() {
		return knownHostsFileName;
	}

	public void setKnownHostsFileName(String knownHostsFileName) {
		this.knownHostsFileName = knownHostsFileName;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public int getPortNo() {
		return portNo;
	}

	public void setPortNo(int portNo) {
		this.portNo = portNo;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getConnectTimeout() {
		return connectTimeout;
	}

	public void setConnectTimeout(int connectTimeout) {
		this.connectTimeout = connectTimeout;
	}
}