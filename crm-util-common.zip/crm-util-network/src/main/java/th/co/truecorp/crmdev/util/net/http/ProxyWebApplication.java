package th.co.truecorp.crmdev.util.net.http;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import th.co.truecorp.crmdev.util.common.UUIDManager;
import th.co.truecorp.crmdev.util.net.ssl.AllowAllHostnameVerifier;
import th.co.truecorp.crmdev.util.net.ssl.SSLTrustManager;

/**
 * 
 * Proxy Web Application Implementation.
 * @author Paravit T.
 * 
 * Configure in "web.xml"
 * <servlet>
 *  	<servlet-name>ProxyWebApplication</servlet-name>
 *   	<servlet-class>th.co.truecorp.crmdev.util.http.ProxyWebApplication</servlet-class>
 *   	<init-param>
 *           <param-name>DESTINATION_URL</param-name>
 *           <param-value>http://172.19.136.92</param-value>
 *   	</init-param>
 *   	<init-param>
 *           <param-name>CONNECT_TIMEOUT</param-name>
 *           <param-value>5000</param-value>
 *   	</init-param>
 *   	<init-param>
 *           <param-name>READ_TIMEOUT</param-name>
 *           <param-value>180000</param-value>
 *   	</init-param>
 * </servlet>
 * <servlet-mapping>
 *		<servlet-name>ProxyWebApplication</servlet-name>
 *   	<url-pattern>/*</url-pattern>
 *   	<url-pattern>*.jsp</url-pattern>
 * </servlet-mapping>
 * 
 */
public class ProxyWebApplication extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	private final String HTTP_HEADER_NAME_HOST = "Host";
    
    private Logger logger;
    private String destinationURL;
    private int connectTimeout;
    private int readTimeout;

    public String getServletInfo() {
        return "Proxy Web Application";
    }

    public void init(ServletConfig servletConfig) throws ServletException {
    	this.logger = LogManager.getLogger(ProxyWebApplication.class);
    	
    	this.destinationURL = servletConfig.getInitParameter("DESTINATION_URL");
    	this.logger.info("destinationURL: " + this.destinationURL);
    	
    	String connectTimeout = servletConfig.getInitParameter("CONNECT_TIMEOUT");
    	if (connectTimeout != null) {
    		this.connectTimeout = Integer.parseInt(connectTimeout);
    	}
    	else {
    		this.connectTimeout = 5000;
    	}
    	this.logger.info("connectTimeout: " + this.connectTimeout);
    	
    	String readTimeout = servletConfig.getInitParameter("READ_TIMEOUT");
    	if (readTimeout != null) {
    		this.readTimeout = Integer.parseInt(readTimeout);
    	}
    	else {
    		this.readTimeout = 180000;
    	}
    	this.logger.info("readTimeout: " + this.readTimeout);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) {
        doPost(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) {
    	HttpURLConnection httpConn = null;
        String transID = null;

        try {
            transID = UUIDManager.getTransactionID();
            this.logger.info(transID + "##### BEGIN PROXY WEB APPLICATION #####");
            
            byte[] requestBinaryData = null;
            
            if (!"GET".equalsIgnoreCase(request.getMethod()) && request.getContentLength() > 0) {
            	requestBinaryData = this.readData(request.getInputStream());
            }
            
            String destURL = this.getDestinationURL(request, transID);
            URL url = null;
            
            if (destURL.startsWith("https")) {
            	// Bypass SSL
            	SSLTrustManager sslTrustManager = new SSLTrustManager();
		    	HttpsURLConnection.setDefaultSSLSocketFactory(sslTrustManager.getSSLSocketFactory());
		    	HttpsURLConnection.setDefaultHostnameVerifier(new AllowAllHostnameVerifier());
		    	
		    	url = new URL(destURL);
		    	httpConn = (HttpsURLConnection) url.openConnection();
            }
            else {
            	url = new URL(destURL);
            	httpConn = (HttpURLConnection) url.openConnection();
            }
            
            httpConn.setRequestMethod(request.getMethod());
            httpConn.setDoOutput(true);
            httpConn.setDoInput(true);
            httpConn.setUseCaches(false);
            httpConn.setAllowUserInteraction(true);
            httpConn.setInstanceFollowRedirects(false); // false = HttpURLConnection was disabled automatic redirect page.
            httpConn.setConnectTimeout(this.getConnectTimeout());
            httpConn.setReadTimeout(this.getReadTimeout());
            
            // Set Request HTTP Headers to destination.
            this.setHttpHeaderRequest(request, httpConn, url, transID);

            httpConn.connect();
            this.logger.debug(transID + "Destination Connected Successfully.");
            
            if (requestBinaryData != null) {
            	this.sendData(httpConn.getOutputStream(), requestBinaryData);
            }

            int httpStatusCode = httpConn.getResponseCode();
            this.logger.debug(transID + "Destination Return HttpStatusCode: " + httpStatusCode);
            
            byte[] responseBinaryData = null;
            
            if (httpStatusCode >= 200 && httpStatusCode < 400) {
            	// Get HTTP Body - Read data from destination.
                responseBinaryData = this.readData(httpConn.getInputStream());
            }
            else {
            	responseBinaryData = this.readData(httpConn.getErrorStream());
            }
            this.logger.debug(transID + "Read Data From Destination Successfully.");
            
            response.setStatus(httpStatusCode);
            this.setHttpHeaderResponse(request, response, httpConn, transID);
            this.sendData(response.getOutputStream(), responseBinaryData);
        }
        catch (SocketException sockEx) {
            try {
            	String errorMessage = "Destination Accessing Error: " + sockEx.getMessage();
            	this.logger.error(errorMessage, sockEx);
            	response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, errorMessage);
            }
            catch (Exception e) {
            }
        }
        catch (Throwable t) {
            try {
            	String errorMessage = "ProxyWebApplication Internal Error: " + t.getMessage();
            	this.logger.error(errorMessage, t);
            	response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, errorMessage);
            }
            catch (Exception e) {
            }
        }
        finally {
            if (httpConn != null) {
                httpConn.disconnect();
                httpConn = null;
            }
            
            this.logger.info(transID + "##### END PROXY WEB APPLICATION #####");
        }
    }
    
    public String getHttpHeaderHost(String url) throws MalformedURLException {
    	String hostName = null;
    	
    	URL urlObj = new URL(url);
    	
    	if (urlObj.getPort() == -1) {
    		hostName = urlObj.getHost();
    	}
    	else {
    		hostName = urlObj.getHost() + ":" + urlObj.getPort();
    	}
    	
    	return hostName;
    }

    private byte[] readData(InputStream inputStream) throws IOException {
    	byte[] binary = null;
    	
    	if (inputStream != null) {
	    	byte[] readBuffer = new byte[1024];
	        ByteArrayOutputStream byteOuts = new ByteArrayOutputStream();
	        while (true) {
	            int count = inputStream.read(readBuffer);
	            if (count == -1) {
	                break;
	            }
	            byteOuts.write(readBuffer, 0, count);
	        }
	        inputStream.close();
	        inputStream = null;
	        
	        binary = byteOuts.toByteArray();
    	}
        
        return binary;
    }
    
    private void sendData(OutputStream outputStream, byte[] binaryData) throws IOException {
        outputStream.write(binaryData);
    	outputStream.flush();
    	outputStream.close();
    	outputStream = null;
    }
    
    private String getDestinationURL(HttpServletRequest request, String transID) {
    	StringBuilder destURL = new StringBuilder();
        destURL.append(this.destinationURL);
        destURL.append(request.getRequestURI());
        
        String queryString = request.getQueryString();
        this.logger.debug(transID + "QueryString: " + queryString);
        
        if (queryString != null) {
             destURL.append("?");
             destURL.append(queryString);
        }
        this.logger.debug(transID + "DestURL: " + destURL.toString());
         
        return destURL.toString();
    }
    
    private void setHttpHeaderRequest(HttpServletRequest request, HttpURLConnection httpConn, URL url, String transID)
    	throws MalformedURLException, UnknownHostException {
    	
    	this.logger.debug(transID + "### Set Request HTTP Headers to destination. ###");
    	String httpHeaderHost = this.getHttpHeaderHost(url.toString());
    	
        Enumeration<String> enumHeaderName = request.getHeaderNames();
        while (enumHeaderName.hasMoreElements()) {
            String headerName = (String)enumHeaderName.nextElement();
            
            if (HTTP_HEADER_NAME_HOST.equalsIgnoreCase(headerName)) {
                httpConn.setRequestProperty(headerName, httpHeaderHost);
                this.logger.debug(transID + headerName + ": " + httpHeaderHost);
            }
            else if ("$WSCS".equalsIgnoreCase(headerName)
            		|| "$WSIS".equalsIgnoreCase(headerName)
            		|| "$WSSC".equalsIgnoreCase(headerName)
            		|| "$WSPR".equalsIgnoreCase(headerName)
            		|| "$WSRA".equalsIgnoreCase(headerName)
            		|| "$WSRH".equalsIgnoreCase(headerName)
            		|| "$WSRU".equalsIgnoreCase(headerName)
            		|| "$WSSN".equalsIgnoreCase(headerName)
            		|| "$WSSP".equalsIgnoreCase(headerName)
            		|| "$WSSI".equalsIgnoreCase(headerName)
            		|| "$WSFO".equalsIgnoreCase(headerName)) {
            	this.logger.debug(transID + "Filter Out WebSphere Header >>> " + headerName + ": " + request.getHeader(headerName));
            }
            else {
                httpConn.setRequestProperty(headerName, request.getHeader(headerName));
                this.logger.debug(transID + headerName + ": " + request.getHeader(headerName));
            }
        }
    }
    
    private void setHttpHeaderResponse(HttpServletRequest request, HttpServletResponse response
    	, HttpURLConnection httpConn, String transID) {
    	
    	// Get Response HTTP Header
        this.logger.debug(transID + "### Get Response HTTP Header ###");
        boolean isGZIPEncoding = false;
        Iterator headerIterator = httpConn.getHeaderFields().entrySet().iterator();
        
        while (headerIterator.hasNext()) {
            Map.Entry mapEntry = (Map.Entry)headerIterator.next();
            
            if (mapEntry.getKey() != null) {
                String headerName = mapEntry.getKey().toString();
                String headerValue = ((List)mapEntry.getValue()).get(0).toString();
                
                if ("Location".equalsIgnoreCase(headerName)) {
                	/* 
                	 * Case Redirect Page
                	 * Http Status Code: 302	Http Header Name ==> Location: http://ip_address:port/contextroot/
                	 */
                	String serverURL = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort();
                	headerValue = headerValue.replaceFirst(this.destinationURL, serverURL);
                }
                
                if ("Content-Encoding".equalsIgnoreCase(headerName) && "gzip".equalsIgnoreCase(headerValue)) {
                    isGZIPEncoding = true;
                }
                
            	response.setHeader(headerName, headerValue);
                this.logger.debug(transID + headerName + ": " + headerValue);
            }
        }
    }

	public int getConnectTimeout() {
		return connectTimeout;
	}

	public void setConnectTimeout(int connectTimeout) {
		this.connectTimeout = connectTimeout;
	}

	public int getReadTimeout() {
		return readTimeout;
	}

	public void setReadTimeout(int readTimeout) {
		this.readTimeout = readTimeout;
	}
}