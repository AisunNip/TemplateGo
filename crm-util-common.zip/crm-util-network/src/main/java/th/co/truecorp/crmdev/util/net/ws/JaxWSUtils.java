package th.co.truecorp.crmdev.util.net.ws;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;
import javax.servlet.http.HttpServletRequest;
import javax.xml.ws.Binding;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.MessageContext;

import com.sun.xml.internal.ws.developer.JAXWSProperties;

import th.co.truecorp.crmdev.util.net.ssl.AllowAllHostnameVerifier;
import th.co.truecorp.crmdev.util.net.ssl.SSLTrustManager;

/**
 * 
 * @author Paravit T.
 * Supported JAX-WS Reference Implementation (RI) Project. https://jax-ws.java.net
 * 
 */
public class JaxWSUtils {
	
	public JaxWSUtils() {
	}
	
	public void setURL(Object port, String wsURL) {
		if (port instanceof BindingProvider) {
			BindingProvider bindingProvider = (BindingProvider) port;
		    Map<String, Object> reqContext = bindingProvider.getRequestContext();
	        reqContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, wsURL);
		}
	}
	
	public void setBasicAuthentication(Object port, String userName, String password) {
		if (port instanceof BindingProvider) {
			BindingProvider bindingProvider = (BindingProvider) port;  
		    Map<String, Object> reqContext = bindingProvider.getRequestContext();  
		    reqContext.put(BindingProvider.USERNAME_PROPERTY, userName);
		    reqContext.put(BindingProvider.PASSWORD_PROPERTY, password);
		}
	}
	
	public void setHandlerChain(Object port, List<Handler> handlerList) {
		if (port instanceof BindingProvider) {
			BindingProvider bindingProvider = (BindingProvider) port;
			Binding binding = bindingProvider.getBinding();
			binding.setHandlerChain(handlerList);
		}
	}
	
	public void setWSSecurity(Object port, String userName, String password) {
		if (port instanceof BindingProvider) {
			WSSecuritySOAPHandler wsSecuritySOAPHandler = new WSSecuritySOAPHandler();
			wsSecuritySOAPHandler.setUserName(userName);
			wsSecuritySOAPHandler.setPassword(password);
			
			List<Handler> soapHandler = new ArrayList<Handler>();
			soapHandler.add(wsSecuritySOAPHandler);
			
			BindingProvider bindingProvider = (BindingProvider) port;
			Binding binding = bindingProvider.getBinding();
			binding.setHandlerChain(soapHandler);
		}
	}
	
	public void setWSSecurity(Object port, String userName, String password
		, String legacyUsername, String legacyPassword) {
		
		if (port instanceof BindingProvider) {
			WSSecuritySOAPHandler wsSecuritySOAPHandler = new WSSecuritySOAPHandler();
			wsSecuritySOAPHandler.setUserName(userName);
			wsSecuritySOAPHandler.setPassword(password);
			wsSecuritySOAPHandler.setLegacyUsername(legacyUsername);
			wsSecuritySOAPHandler.setLegacyPassword(legacyPassword);
			
			List<Handler> soapHandler = new ArrayList<Handler>();
			soapHandler.add(wsSecuritySOAPHandler);
			
			BindingProvider bindingProvider = (BindingProvider) port;
			Binding binding = bindingProvider.getBinding();
			binding.setHandlerChain(soapHandler);
		}
	}
	
	/**
	 * 
	 * @param wsContext is mandatory.
	 * @return user name
	 */
	public String getUserPrincipal(WebServiceContext wsContext) {
		Principal userPrincipal = wsContext.getUserPrincipal();
		return userPrincipal.getName();
	}
	
	public boolean isUserInRole(WebServiceContext wsContext, String role) {
		return wsContext.isUserInRole(role);
	}
	
	public HttpServletRequest getHttpServletRequest(WebServiceContext wsContext) {
		return (HttpServletRequest) wsContext.getMessageContext().get(MessageContext.SERVLET_REQUEST);
	}
	
	public String getRequestURL(WebServiceContext wsContext) {
		HttpServletRequest request = this.getHttpServletRequest(wsContext);
		return request.getRequestURL().toString();
	}
	
	/**
	 * Server side.
	 * @param wsContext is mandatory.
	 * @return
	 */
	public Map<String, List<String>> getHttpRequestHeaders(WebServiceContext wsContext) {
		MessageContext msgContext = wsContext.getMessageContext();
		Map<String, List<String>> httpHeaders = (Map<String, List<String>>) msgContext.get(MessageContext.HTTP_REQUEST_HEADERS);
		return httpHeaders;
	}
	
	/**
	 * Client side.
	 * @param proxy is mandatory.
	 * @param headers
	 */
	public void setHttpRequestHeaders(Object proxy, Map<String, List<String>> headers) {
		if (headers != null) {
	        Map<String, Object> reqContext = ((BindingProvider)proxy).getRequestContext();
	        reqContext.put(MessageContext.HTTP_REQUEST_HEADERS, headers);
		}
        /*
        Map<String, List<String>> headers = new HashMap<String, List<String>>();
        headers.put("Username", Collections.singletonList("paravit"));
        headers.put("Password", Collections.singletonList("my password"));
        */
	}
	
	public void setSSLSocketFactory(Object port, SSLSocketFactory sslSocketFactory) {
		if (port instanceof BindingProvider) {
			BindingProvider bindingProvider = (BindingProvider) port;
		    Map<String, Object> reqContext = bindingProvider.getRequestContext();
		    reqContext.put(JAXWSProperties.SSL_SOCKET_FACTORY, sslSocketFactory);
		    reqContext.put(JAXWSProperties.HOSTNAME_VERIFIER, new AllowAllHostnameVerifier());
		}
	}
	
	public void setBypassSSL() throws KeyManagementException, NoSuchAlgorithmException {
		SSLTrustManager sslTrustManager = new SSLTrustManager();
    	HttpsURLConnection.setDefaultSSLSocketFactory(sslTrustManager.getSSLSocketFactory());
    	HttpsURLConnection.setDefaultHostnameVerifier(new AllowAllHostnameVerifier());
	}
	
	public void setTimeout(Object port, int connectTimeout, int readTimeout) {
		if (port instanceof BindingProvider) {
			BindingProvider bindingProvider = (BindingProvider) port;
		    Map<String, Object> reqContext = bindingProvider.getRequestContext();
		    reqContext.put(JAXWSProperties.CONNECT_TIMEOUT, connectTimeout);
		    reqContext.put(JAXWSProperties.REQUEST_TIMEOUT, readTimeout);
		    // Apache CXF
		    reqContext.put("javax.xml.ws.client.connectionTimeout", String.valueOf(connectTimeout));
		    reqContext.put("javax.xml.ws.client.receiveTimeout", String.valueOf(readTimeout));
		}
	}
	
	public void setConnectTimeout(Object port, int timeout) {
		if (port instanceof BindingProvider) {
			BindingProvider bindingProvider = (BindingProvider) port;
		    Map<String, Object> reqContext = bindingProvider.getRequestContext();
		    reqContext.put(JAXWSProperties.CONNECT_TIMEOUT, timeout);
		    reqContext.put("javax.xml.ws.client.connectionTimeout", String.valueOf(timeout));
		}
	}
	
	public void setReadTimeout(Object port, int timeout) {
		if (port instanceof BindingProvider) {
			BindingProvider bindingProvider = (BindingProvider) port;
		    Map<String, Object> reqContext = bindingProvider.getRequestContext();
		    reqContext.put(JAXWSProperties.REQUEST_TIMEOUT, timeout);
		    reqContext.put("javax.xml.ws.client.receiveTimeout", String.valueOf(timeout));
		}
	}
}