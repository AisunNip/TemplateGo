package th.co.truecorp.crmdev.util.net.xml;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Attr;
import org.w3c.dom.Comment;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.InputSource;

import th.co.truecorp.crmdev.util.common.CalendarManager;
import th.co.truecorp.crmdev.util.common.TextEncoding;
import th.co.truecorp.crmdev.util.net.bean.XMLProperties;

/**
 *
 * @author Paravit T.
 * 
 */
public class XMLManager {
	
    public final String XML_VERSION_1_0 = "1.0";
    public final String XML_VERSION_1_1 = "1.1";
    
    private String charset;
    // connectTimeout in milliseconds.
    private int connectTimeout;
    // readTimeout in milliseconds.
    private int readTimeout;
    
    public XMLManager() {
		this.charset = "UTF-8";
		this.connectTimeout = 5000;
		this.readTimeout = 30000;
	}

	public String getCharset() {
		return charset;
	}

	public void setCharset(String charset) {
		this.charset = charset;
	}

	public int getConnectTimeout() {
		return connectTimeout;
	}

	public void setConnectTimeout(int connectTimeout) {
		this.connectTimeout = connectTimeout;
	}

	public int getReadTimeout() {
		return readTimeout;
	}

	public void setReadTimeout(int readTimeout) {
		this.readTimeout = readTimeout;
	}

	public Document createDocument(String xmlVersion, boolean isStandalone) {
        Document document = null;

        try {
            if (xmlVersion == null || "".equals(xmlVersion)) {
                xmlVersion = this.XML_VERSION_1_0;
            }

            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            document = docBuilder.newDocument();
            // XML declaration
            document.setXmlVersion(xmlVersion);
            document.setXmlStandalone(isStandalone);
        }
        catch (ParserConfigurationException e) {
            e.printStackTrace();
        }

        return document;
    }

    public Element createElement(Document document, String tagName
        , Properties attributes, String textNode) {

        Element element = null;

        if (document != null) {
            element = document.createElement(tagName);
            
            if (attributes != null) {
                Enumeration<Object> enumKeys = attributes.keys();
                while (enumKeys.hasMoreElements()) {
                    String keyName = (String)enumKeys.nextElement();
                    element.setAttribute(keyName, attributes.getProperty(keyName));
                }
            }

            if (textNode != null && !"".equals(textNode)) {
                element.appendChild(document.createTextNode(textNode));
            }
        }

        return element;
    }

    public Attr createAttribute(Document document, String attrName, String attrValue) {
        Attr attribute = document.createAttribute(attrName);
        attribute.setValue(attrValue);
        
        return attribute;
    }

    public Text createTextNode(Document document, String textContent) {
        return document.createTextNode(textContent);
    }

    public Comment createComment(Document document, String textComment) {
        return document.createComment(textComment);
    }

    public Element getRootElement(Document document) {
        return document.getDocumentElement();
    }

    public Element getParentElement(Element currElement) {
        Element parentElement = null;

        Node parent = currElement.getParentNode();
        if (parent instanceof Element) {
            parentElement = (Element)parent;
        }

        return parentElement;
    }

    public Element[] getChildElement(Element currElement) {
        Element childElement[] = null;
        ArrayList<Element> childElementList = new ArrayList<Element>();

        NodeList childList = currElement.getChildNodes();
        for (int i=0; i < childList.getLength(); i++) {
            Node child = childList.item(i);
            if (child instanceof Element) {
                childElementList.add((Element)child);
            }
        }

        if (childElementList.size() > 0) {
            // Convert ArrayList to array.
            childElement = (Element[])childElementList.toArray(new Element[0]);

            // Release Memory.
            childElementList.clear();
            childElementList = null;
        }

        return childElement;
    }
    
    public String getTextContent(Node node) {
    	return node == null ? null : node.getTextContent();
    }
    
    public Element nodeToElement(Node node) {
    	Element element = null;
    	
    	if (node != null) {
    		if (node instanceof Element) {
    			element = (Element) node;
    		}
    	}
    	
    	return element;
    }
    
    public Element[] nodeListToElement(NodeList nodeList) {
    	Element element[] = null;
    	
    	if (nodeList != null) {
	    	ArrayList<Element> elementList = new ArrayList<Element>();
	    	
	    	for (int i=0; i < nodeList.getLength(); i++) {
	            Node child = nodeList.item(i);
	            if (child instanceof Element) {
	                elementList.add((Element)child);
	            }
	        }
	
	        if (elementList.size() > 0) {
	            // Convert ArrayList to array.
	            element = (Element[])elementList.toArray(new Element[0]);
	
	            // Release Memory.
	            elementList.clear();
	            elementList = null;
	        }
    	}

        return element;
    }

    public Node xmlPropertiesToNode(Document document, XMLProperties xmlProperties) {
        Node node = null;

        if (document != null) {
            Element element = document.createElement(xmlProperties.getTagName());

            String textNode = xmlProperties.getTextNode();
            if (textNode != null && !"".equals(textNode)) {
                element.appendChild(document.createTextNode(textNode));
            }

            Properties attributes = xmlProperties.getAttribute();
            if (attributes != null) {
                Enumeration<Object> enumKeys = attributes.keys();
                while (enumKeys.hasMoreElements()) {
                    String keyName = (String)enumKeys.nextElement();
                    element.setAttribute(keyName, attributes.getProperty(keyName));
                }
            }
            
            XMLProperties childProp[] = xmlProperties.getChildNodes();
            if (childProp != null) {
                for (int i = 0; i < childProp.length; i++) {
                    Node childNode = xmlPropertiesToNode(document, childProp[i]);
                    element.appendChild(childNode);
                }
            }

            node = (Node)element;
        }

        return node;
    }

    public XMLProperties nodeToXMLProperties(Node currNode) {
        XMLProperties xmlProperties = null;

        if (currNode != null) {
            xmlProperties = new XMLProperties();
            xmlProperties.setTagName(currNode.getNodeName());
            
            // Get Attribute
            if (currNode.hasAttributes()) {
                Properties attributeProp = new Properties();
                NamedNodeMap namedNodeMap = currNode.getAttributes();
                for (int i=0; i < namedNodeMap.getLength(); i++) {
                    Attr attribute = (Attr)namedNodeMap.item(i);
                    attributeProp.setProperty(attribute.getName(), attribute.getValue());
                }
                xmlProperties.setAttribute(attributeProp);
            }

            // Get Text Node
            if (currNode.hasChildNodes()) {
                NodeList childList = currNode.getChildNodes();
                for (int i=0; i < childList.getLength(); i++) {
                    Node childNode = childList.item(i);
                    if (childNode.getNodeType() == Node.TEXT_NODE) {
                        xmlProperties.setTextNode(childNode.getNodeValue());
                    }
                    else if (childNode.getNodeType() == Node.ELEMENT_NODE) {
                        xmlProperties.appendChildNode(nodeToXMLProperties(childNode));
                    }
                }
            }
        }

        return xmlProperties;
    }

    public boolean removeAttribute(Element element, String attrName) {
        boolean isRemove = false;

        try {
            NamedNodeMap namedNodeMap = element.getAttributes();
            Node attrNode = namedNodeMap.removeNamedItem(attrName);
            isRemove = true;
        }
        catch (DOMException domEx) {
            domEx.printStackTrace();
        }

        return isRemove;
    }

    public String domToString(Document dom) {
        String xmlString = null;
        StringWriter stringWriter = null;
        
        try {
            Source source = new DOMSource(dom);
            
            stringWriter = new StringWriter();
            StreamResult result = new StreamResult(stringWriter);

            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer();
            transformer.transform(source, result);
            
            xmlString = stringWriter.getBuffer().toString();
        }
        catch (TransformerConfigurationException transfConfEx) {
            transfConfEx.printStackTrace();
        }
        catch (TransformerException transfEx) {
            transfEx.printStackTrace();
        }
        finally {
        	try {
	        	if (stringWriter != null) {
	        		stringWriter.close();
	        	}
        	}
        	catch (Exception e) {
        		e.printStackTrace();
        	}
        }

        return xmlString;
    }

    public Document stringToDOM(String xml) {
        Document dom = null;

        try {
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            InputSource is = new InputSource(new StringReader(xml));
            dom = docBuilder.parse(is);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }

        return dom;
    }

    public Document readXMLFile(String fileName) throws Exception {
    	Document doc = null;
    	FileInputStream fileInputStream = null;
    	
    	try {
            fileInputStream = new FileInputStream(new File(fileName));
            
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            doc = docBuilder.parse(fileInputStream);
    	}
    	finally {
    		if (fileInputStream != null) {
    			fileInputStream.close();
    			fileInputStream = null;
    		}
    	}
    	
    	return doc;
    }
    
    public String readXMLFileToString(String fileName) {
        String xmlString = null;
        
        try {
            Document doc = this.readXMLFile(fileName);

            StringWriter stringWriter = new StringWriter();
            StreamResult result = new StreamResult(stringWriter);

            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer();
            transformer.transform(new DOMSource(doc), result);

            xmlString = stringWriter.getBuffer().toString();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        
        return xmlString;
    }

    public boolean writeDOMToXMLFile(Document doc, String fileName) {
        boolean isWrite = false;

        try {
            // Prepare the DOM document for writing
            Source source = new DOMSource(doc);

            // Prepare the output file
            File file = new File(fileName);
            StreamResult result = new StreamResult(file);

            // Write the DOM document to the file
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer();
            transformer.transform(source, result);

            isWrite = true;
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }

        return isWrite;
    }
    
    public String objectToXMLString(Object obj) {
    	String xml = null;
    	
    	if (obj != null) {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			XMLEncoder xmlEncoder = new XMLEncoder(baos);
			xmlEncoder.writeObject(obj);
			xmlEncoder.close();
			
			xml = baos.toString();
    	}
    	
		return xml;
	}
    
    /**
     * 
     * @param rs is mandatory.
     * @param calendarPattern is mandatory such as "dd/MM/yyyy HH:mm:ss"
     * @param tagName is mandatory.
     * @return xml string
     * @throws SQLException 
     */
    public String resultSetToXML(ResultSet rs, String calendarPattern, String tagName) throws SQLException {
    	String xml = null;
    	
    	if (rs != null) {
    		LinkedHashMap<String, Integer> rsMetaDataHM = null;
    		
    		String rootTagName = "ListOf" + tagName;
    		StringBuilder xmlBuilder = new StringBuilder();
    		xmlBuilder.append("<");
    		xmlBuilder.append(rootTagName);
    		xmlBuilder.append(">");
    		
    		while (rs.next()) {
    			// Get ResultSetMetaData
    			if (rsMetaDataHM == null) {
    				rsMetaDataHM = new LinkedHashMap<String, Integer>();
    				
	    			ResultSetMetaData rsMetaData = rs.getMetaData();
	                for (int columnIndex = 1; columnIndex <= rsMetaData.getColumnCount(); columnIndex++) {
	                	String columnName = rsMetaData.getColumnName(columnIndex);
	                	int columnType = rsMetaData.getColumnType(columnIndex);
	                	
	                	rsMetaDataHM.put(columnName, new Integer(columnType));
	                }
    			}
    			
                xmlBuilder.append("<");
    			xmlBuilder.append(tagName);
    			
    			Iterator<Entry<String, Integer>> i = rsMetaDataHM.entrySet().iterator();
    			while (i.hasNext()) {
    		        Map.Entry<String, Integer> mapEntry = (Map.Entry<String, Integer>)i.next();
    		        String columnName = mapEntry.getKey();
    		        int columnType = mapEntry.getValue();
    		        String columnValue = null;
                	
                    if (columnType == Types.DATE || columnType == Types.TIMESTAMP) {
                    	Timestamp timeStamp = rs.getTimestamp(columnName, CalendarManager.getEngCalendar());
                    	Calendar cal = CalendarManager.timestampToCalendar(timeStamp, CalendarManager.LOCALE_EN);
                    	columnValue = CalendarManager.calendarToString(cal, calendarPattern, CalendarManager.LOCALE_EN);
                    }
                    else {
                    	columnValue = rs.getString(columnName);
                    }
                    
                    if (columnValue == null) {
                    	columnValue = "";
                    }
                	
                    xmlBuilder.append(" ");
                    xmlBuilder.append(columnName.toLowerCase());
                    xmlBuilder.append("=\"");
                    xmlBuilder.append(TextEncoding.encodeXML(columnValue));
                    xmlBuilder.append("\"");
    			}
                
                xmlBuilder.append(">");
                xmlBuilder.append("</");
        		xmlBuilder.append(tagName);
        		xmlBuilder.append(">");
    		}
    		
    		xmlBuilder.append("</");
    		xmlBuilder.append(rootTagName);
    		xmlBuilder.append(">");
    		
    		xml = xmlBuilder.toString();
    		
    		if (rsMetaDataHM != null) {
    			rsMetaDataHM.clear();
    			rsMetaDataHM = null;
    		}
    	}
    	
    	return xml;
    }
    
    public Object xmlStringToObject(String xml) throws UnsupportedEncodingException {
    	Object obj = null;
    	
    	if (xml != null) {
	    	XMLDecoder decoder = new XMLDecoder(new ByteArrayInputStream(xml.getBytes(this.charset)));
	    	obj = decoder.readObject();
	    	decoder.close();
    	}
    	
    	return obj;
    }

    public XPath newXPath() {
    	XPathFactory xPathFactory = XPathFactory.newInstance();
		// Create a XPath object
		return xPathFactory.newXPath();
    }
    
    public Object queryXPath(String expression, Document doc, QName returnType)
    	throws XPathExpressionException {
    	
		XPath xPath = this.newXPath();
		// Compile the XPath expression
		XPathExpression xPathExpr = xPath.compile(expression);
		
		return xPathExpr.evaluate(doc, returnType);
    }
    
    public String queryXPath(String expression, Document doc)
    	throws XPathExpressionException {
    	
		return (String) this.queryXPath(expression, doc, XPathConstants.STRING);
    }
    
    public Node queryXPathNode(String expression, Document doc)
        throws XPathExpressionException {
        	
    	return (Node) this.queryXPath(expression, doc, XPathConstants.NODE);
    }
    
    public NodeList queryXPathNodeList(String expression, Document doc)
        throws XPathExpressionException {
        	
    	return (NodeList) this.queryXPath(expression, doc, XPathConstants.NODESET);
    }
    
    public String xsltTransformer(String xml, String xsltFileName) throws TransformerException {
        String xmlString = null;
        
        StreamSource source = new StreamSource(new StringReader(xml));
        StreamSource styleSheet = new StreamSource(xsltFileName);

        StringWriter stringWriter = new StringWriter();
        StreamResult result = new StreamResult(stringWriter);

        // Create a TransformerFactory object.
        TransformerFactory factory = TransformerFactory.newInstance();
        Transformer transformer = factory.newTransformer(styleSheet);
        transformer.transform(source, result);

        xmlString = stringWriter.getBuffer().toString();
        
        return xmlString;
    }
    
    public String removeProlog(String xml) throws TransformerException {
        String xmlString = null;
        
        StreamSource source = new StreamSource(new StringReader(xml));

        StringWriter stringWriter = new StringWriter();
        StreamResult result = new StreamResult(stringWriter);

        // Create a TransformerFactory object.
        TransformerFactory factory = TransformerFactory.newInstance();
        Transformer transformer = factory.newTransformer();
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        transformer.transform(source, result);

        xmlString = stringWriter.getBuffer().toString();

        return xmlString;
    }
    
}