package th.co.truecorp.crmdev.util.net;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import th.co.truecorp.crmdev.util.net.bean.NetworkInterfaceBean;

/**
 *
 * @author Paravit T.
 * The InetAddress class provides methods to resolve host names to their IP addresses and vice versa.
 * Forward DNS - convert host name to IP address.
 * Reverse DNS - convert IP address to host name.
 * 
 */
public class InternetProtocol {
	
    public InternetProtocol() {
    }

    public String getIPAddress() throws UnknownHostException {
        InetAddress inetAddr = InetAddress.getLocalHost();
        return inetAddr.getHostAddress();
    }
    
    /**
     * Connect to DNS server. Determines the IP address of a host.
     * @param host
     * @return an IP address
     * @throws UnknownHostException
     */
    public InetAddress getByName(String host) throws UnknownHostException {
    	return InetAddress.getByName(host);
    }
    
    /**
     * Connect to DNS server. 
     * @param ipAddress
     * @return an InetAddress object.
     * @throws UnknownHostException
     */
    public InetAddress getByAddress(String ipAddress) throws UnknownHostException {
    	byte[] addr = null;
    	
    	if (ipAddress != null && !"".equals(ipAddress)) {
    		String[] tempIpAddress = ipAddress.split("\\.");
    		addr = new byte[tempIpAddress.length];
    		for (int i=0; i < tempIpAddress.length; i++) {
    			addr[i] = Integer.valueOf(tempIpAddress[i]).byteValue();
    		}
    	}
    	
    	return InetAddress.getByAddress(addr);
    }
    
    public String getHostName() throws UnknownHostException {
        InetAddress inetAddr = InetAddress.getLocalHost();
        return inetAddr.getHostName();
    }
    
    public String getHostName(String url) throws MalformedURLException {
        URL urlObj = new URL(url);
        return urlObj.getHost();
    }

    public String getRemoteIPAddress(HttpServletRequest httpReq) {
        return httpReq.getRemoteAddr();
    }

    public String getRemoteHostName(HttpServletRequest httpReq) {
        return httpReq.getRemoteHost();
    }
    
    public String getClientIPAddress(HttpServletRequest httpReq) {
    	String clientIPAddress = null;
    	
    	String xForwardedFor = httpReq.getHeader("X-Forwarded-For");
    	String xRealIP = httpReq.getHeader("X-Real-IP");
    	
    	if (xForwardedFor != null) {
    		int index = xForwardedFor.indexOf(",");
    		
    		if (index == -1) {
    			clientIPAddress = xForwardedFor;
    		}
    		else {
    			clientIPAddress = xForwardedFor.substring(0, index);
    		}
    		
    		clientIPAddress = clientIPAddress.trim();
    	}
    	else if (xRealIP != null) {
    		clientIPAddress = xRealIP.trim();
    	}
    	else {
    		clientIPAddress = httpReq.getRemoteAddr();
    	}
    	
        return clientIPAddress;
    }
    
    public List<NetworkInterfaceBean> getNetworkInterfaces() throws SocketException {
    	List<NetworkInterfaceBean> networkInterfaceList = new ArrayList<NetworkInterfaceBean>();
    	
    	Enumeration<NetworkInterface> niEnum = NetworkInterface.getNetworkInterfaces();
    	while (niEnum.hasMoreElements()) {
    		NetworkInterface ni = niEnum.nextElement();
    		
    		NetworkInterfaceBean networkInterfaceBean = new NetworkInterfaceBean();
    		networkInterfaceBean.setDisplayName(ni.getDisplayName());
    		networkInterfaceBean.setName(ni.getName());
    		
    		byte[] mac = ni.getHardwareAddress();
    		if (mac != null) {
    			StringBuilder sb = new StringBuilder();
    			for (int i = 0; i < mac.length; i++) {
    				sb.append(String.format("%02X%s", mac[i], (i < mac.length - 1) ? "-" : ""));		
    			}
    			
    			networkInterfaceBean.setMacAddress(sb.toString());
    		}
    		
    		networkInterfaceList.add(networkInterfaceBean);
    	}
    	
    	return networkInterfaceList;
    }
}