package th.co.truecorp.crmdev.util.net.rest;

import java.text.SimpleDateFormat;

import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

/**
*
* @author Paravit T.
* 
* Jackson 2.9.5 compatible with JDK 1.8
* 
* Registering via web.xml
* 	<context-param>
*		<param-name>resteasy.scan</param-name>
*		<param-value>true</param-value>
*  	</context-param>
*  	<context-param>
* 		<param-name>resteasy.providers</param-name>
*    	<param-value>th.co.truecorp.crmdev.util.rest.RestJsonProvider</param-value>
*  	</context-param>
* 
*/
@Provider
public class RestJsonProvider implements ContextResolver<ObjectMapper> {

	private final ObjectMapper objMapper;

	public RestJsonProvider() throws Exception {
		objMapper = new ObjectMapper();
		objMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        objMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ"));
        objMapper.enable(SerializationFeature.INDENT_OUTPUT);
        objMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		objMapper.setSerializationInclusion(Include.NON_NULL);
	}

	@Override
	public ObjectMapper getContext(Class<?> type) {
		return objMapper;
	}
}