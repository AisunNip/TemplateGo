package th.co.truecorp.crmdev.util.net.ws;

import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPFactory;
import javax.xml.soap.SOAPHeader;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 
 * @author Paravit T.
 * JAX-WS Handler for web service security.
 * 
 */
public class WSSecuritySOAPHandler implements SOAPHandler<SOAPMessageContext> {

	private Logger logger;
	private String userName;
	private String password;
	private String legacyUsername;
	private String legacyPassword;

	public WSSecuritySOAPHandler() {
		this.logger = LogManager.getLogger(WSSecuritySOAPHandler.class);
	}

	@Override
	public boolean handleMessage(SOAPMessageContext context) {
		try {
			Boolean outboundProperty = (Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
	
			if (outboundProperty.booleanValue()) {
				this.logger.info("Outbound Message");
				this.logger.info("WSSecurity userName: " + this.userName + ", password: " + this.password);
				
				SOAPEnvelope soapEnvelope = context.getMessage().getSOAPPart().getEnvelope();
				SOAPFactory soapFactory = SOAPFactory.newInstance();
				String prefix = "wsse";
				String uri = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd";

				SOAPElement securityElem = soapFactory.createElement("Security", prefix, uri);

				SOAPElement tokenElem = soapFactory.createElement("UsernameToken", prefix, uri);
				tokenElem.addAttribute(QName.valueOf("wsu:Id"), "UsernameToken-1");
				tokenElem.addAttribute(QName.valueOf("xmlns:wsu"), "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd");

				SOAPElement userNameElem = soapFactory.createElement("Username", prefix, uri);
				userNameElem.addTextNode(this.userName);

				SOAPElement passwordElem = soapFactory.createElement("Password", prefix, uri);
				passwordElem.addAttribute(QName.valueOf("Type"), "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText");
				passwordElem.addTextNode(this.password);
				
				tokenElem.addChildElement(userNameElem);
				tokenElem.addChildElement(passwordElem);
				
				if (this.getLegacyUsername() != null) {
					SOAPElement legacyUsernameElem = soapFactory.createElement("LegacyUsername", prefix, uri);
					legacyUsernameElem.addTextNode(this.getLegacyUsername());
					
					tokenElem.addChildElement(legacyUsernameElem);
				}
				
				if (this.getLegacyPassword() != null) {
					SOAPElement legacyPasswordElem = soapFactory.createElement("LegacyPassword", prefix, uri);
					legacyPasswordElem.addAttribute(QName.valueOf("Type"), "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText");
					legacyPasswordElem.addTextNode(this.getLegacyPassword());
					
					tokenElem.addChildElement(legacyPasswordElem);
				}

				securityElem.addChildElement(tokenElem);
				
				SOAPHeader soapHeader = soapEnvelope.getHeader();
				soapHeader.setPrefix("soap");
				soapHeader.addAttribute(QName.valueOf("xmlns:soap"), "http://schemas.xmlsoap.org/soap/envelope/");
				soapHeader.addChildElement(securityElem);
			}
			else {
				this.logger.info("Inbound Message");
			}
		}
		catch (Throwable t) {
			this.logger.error(t.getMessage(), t);
		}

		return true;
	}

	@Override
	public Set<QName> getHeaders() {
		return null;
	}

	@Override
	public boolean handleFault(SOAPMessageContext context) {
		return false;
	}

	@Override
	public void close(MessageContext context) {
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getLegacyUsername() {
		return legacyUsername;
	}

	public void setLegacyUsername(String legacyUsername) {
		this.legacyUsername = legacyUsername;
	}

	public String getLegacyPassword() {
		return legacyPassword;
	}

	public void setLegacyPassword(String legacyPassword) {
		this.legacyPassword = legacyPassword;
	}
}