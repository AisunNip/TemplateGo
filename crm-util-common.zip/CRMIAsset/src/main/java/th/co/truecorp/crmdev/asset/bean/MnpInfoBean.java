package th.co.truecorp.crmdev.asset.bean;

public class MnpInfoBean {
	
	private String mnpPortType;
	private String mnpDonorOper;
	private String mnpDonorZone;
	private String mnpRecOper;
	private String mnpRecZone;

	public MnpInfoBean() {		
	}

	public String getMnpPortType() {
		return mnpPortType;
	}

	public void setMnpPortType(String mnpPortType) {
		this.mnpPortType = mnpPortType;
	}

	public String getMnpDonorOper() {
		return mnpDonorOper;
	}

	public void setMnpDonorOper(String mnpDonorOper) {
		this.mnpDonorOper = mnpDonorOper;
	}

	public String getMnpDonorZone() {
		return mnpDonorZone;
	}

	public void setMnpDonorZone(String mnpDonorZone) {
		this.mnpDonorZone = mnpDonorZone;
	}

	public String getMnpRecOper() {
		return mnpRecOper;
	}

	public void setMnpRecOper(String mnpRecOper) {
		this.mnpRecOper = mnpRecOper;
	}

	public String getMnpRecZone() {
		return mnpRecZone;
	}

	public void setMnpRecZone(String mnpRecZone) {
		this.mnpRecZone = mnpRecZone;
	}
		
}
