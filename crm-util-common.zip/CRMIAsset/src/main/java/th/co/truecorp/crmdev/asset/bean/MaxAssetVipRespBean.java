package th.co.truecorp.crmdev.asset.bean;

public class MaxAssetVipRespBean extends ResponseBean {
	
	private static final long serialVersionUID = 1L;

	private String maxAssetVip;

	public String getMaxAssetVip() {
		return maxAssetVip;
	}

	public void setMaxAssetVip(String maxAssetVip) {
		this.maxAssetVip = maxAssetVip;
	}

}
